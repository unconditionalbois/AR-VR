using UnityEngine; using UnityEngine.UI; using UnityEngine.EventSystems;
public static class UiBuilder {
  public static Canvas Canvas(string name, bool world = false){
    var go = new GameObject(name, typeof(RectTransform));
    var c = go.AddComponent<Canvas>(); go.AddComponent<CanvasScaler>(); go.AddComponent<GraphicRaycaster>();
    if (world){ c.renderMode = RenderMode.WorldSpace; go.GetComponent<RectTransform>().sizeDelta = new Vector2(500, 400); go.transform.localScale = Vector3.one * 0.004f; }
    else c.renderMode = RenderMode.ScreenSpaceOverlay;
    if (Object.FindFirstObjectByType<EventSystem>() == null){ var es = new GameObject("EventSystem"); es.AddComponent<EventSystem>(); es.AddComponent<StandaloneInputModule>(); }
    return c;
  }
  public static RectTransform Rt(string n, Transform p, Vector2 size, Vector2 pos){
    var g = new GameObject(n, typeof(RectTransform)); g.transform.SetParent(p, false);
    var r = g.GetComponent<RectTransform>(); r.anchorMin = r.anchorMax = new Vector2(.5f, .5f); r.sizeDelta = size; r.anchoredPosition = pos; return r;
  }
  public static Image Panel(Transform p, Vector2 size, Vector2 pos){
    var r = Rt("Panel", p, size, pos); var i = r.gameObject.AddComponent<Image>(); i.color = new Color(0, 0, 0, .65f); return i;
  }
  public static Text Label(Transform p, string t, Vector2 size, Vector2 pos, int fs = 24){
    var r = Rt("Text", p, size, pos); var x = r.gameObject.AddComponent<Text>();
    x.text = t; x.fontSize = fs; x.alignment = TextAnchor.MiddleCenter; x.color = Color.white;
    x.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); return x;
  }
  public static Button Btn(Transform p, string t, Vector2 pos){
    var r = Rt("Button_" + t, p, new Vector2(220, 50), pos); var im = r.gameObject.AddComponent<Image>(); im.color = new Color(.2f, .5f, .9f);
    var b = r.gameObject.AddComponent<Button>(); b.targetGraphic = im; Label(r, t, new Vector2(220, 50), Vector2.zero, 22); return b;
  }
}
