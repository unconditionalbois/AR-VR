using UnityEngine; using UnityEditor; using UnityEditor.SceneManagement; using System.IO;
using UnityEngine.UI;
[InitializeOnLoad]
public static class Ex02Builder {
  const string ScenePath = "Assets/Scenes/Ex02_InteractiveScene.unity";
  static Ex02Builder() {
    EditorApplication.delayCall += () => {
      if (EditorApplication.isPlayingOrWillChangePlaymode) return;
      if (!File.Exists(ScenePath)) Build();
    };
  }
  [MenuItem("AR-VR Practical/Rebuild Ex02_InteractiveScene Scene")]
  public static void Build() {
    Util.Folder("Assets/Scenes");
    var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

    Util.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(1.5f,1,1.5f), new Color(.5f,.5f,.5f));
    for (int i = 0; i < 4; i++) {
      var c = Util.Prim(PrimitiveType.Cube, "PhysicsCube" + i, new Vector3(-1.5f + i, 1 + i * .3f, 0), Vector3.one * .8f, Color.red);
      var rb = c.AddComponent<Rigidbody>(); rb.mass = 1f; rb.linearDamping = 0.1f; rb.useGravity = true;
    }
    var s = Util.Prim(PrimitiveType.Sphere, "PhysicsSphere", new Vector3(0, 4, 0), Vector3.one, Color.blue);
    s.AddComponent<Rigidbody>();
    var canvas = UiBuilder.Canvas("Canvas");
    var logic = new GameObject("UIManager").AddComponent<InteractiveUI>();
    var panel = UiBuilder.Panel(canvas.transform, new Vector2(300, 260), new Vector2(-330, -140));
    UiBuilder.Label(panel.transform, "Physics Playground", new Vector2(280, 40), new Vector2(0, 100), 24);
    logic.counter = UiBuilder.Label(panel.transform, "Balls spawned: 0", new Vector2(280, 40), new Vector2(0, 50), 20);
    var b1 = UiBuilder.Btn(panel.transform, "Drop Ball", new Vector2(0, -10));
    var b2 = UiBuilder.Btn(panel.transform, "Reset", new Vector2(0, -75));
    UnityEditor.Events.UnityEventTools.AddPersistentListener(b1.onClick, logic.SpawnBall);
    UnityEditor.Events.UnityEventTools.AddPersistentListener(b2.onClick, logic.ResetScene);
    Camera.main.transform.position = new Vector3(0, 3, -8); Camera.main.transform.LookAt(Vector3.up);

    EditorSceneManager.SaveScene(scene, ScenePath);
    Util.AddToBuild(ScenePath);
    AssetDatabase.Refresh();
    Debug.Log("Ex02_InteractiveScene scene created: " + ScenePath);
  }
}
