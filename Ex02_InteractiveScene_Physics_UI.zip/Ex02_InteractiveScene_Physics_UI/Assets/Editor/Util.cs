using UnityEngine; using UnityEditor; using System.IO;
public static class Util {
  public static void Folder(string path){
    if (AssetDatabase.IsValidFolder(path)) return;
    string parent = Path.GetDirectoryName(path).Replace("\\","/");
    if (!AssetDatabase.IsValidFolder(parent)) Folder(parent);
    AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
  }
  public static Material Mat(Color c){
    Folder("Assets/Materials");
    string p = "Assets/Materials/M_" + ColorUtility.ToHtmlStringRGB(c) + ".mat";
    var m = AssetDatabase.LoadAssetAtPath<Material>(p);
    if (m == null){ m = new Material(Shader.Find("Standard")); m.color = c; AssetDatabase.CreateAsset(m, p); }
    return m;
  }
  public static GameObject Prim(PrimitiveType t, string name, Vector3 pos, Vector3 scale, Color c){
    var g = GameObject.CreatePrimitive(t); g.name = name; g.transform.position = pos; g.transform.localScale = scale;
    g.GetComponent<Renderer>().sharedMaterial = Mat(c); return g;
  }
  public static void AddToBuild(params string[] paths){
    var list = new System.Collections.Generic.List<EditorBuildSettingsScene>();
    foreach (var p in paths) list.Add(new EditorBuildSettingsScene(p, true));
    EditorBuildSettings.scenes = list.ToArray();
  }
}
