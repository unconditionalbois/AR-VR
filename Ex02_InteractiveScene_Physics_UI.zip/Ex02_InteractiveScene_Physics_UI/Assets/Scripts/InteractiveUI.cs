using UnityEngine; using UnityEngine.UI; using UnityEngine.SceneManagement;
public class InteractiveUI : MonoBehaviour {
  public Text counter; int n;
  public void SpawnBall() {
    var b = GameObject.CreatePrimitive(PrimitiveType.Sphere);
    b.transform.position = new Vector3(Random.Range(-2f, 2f), 6f, Random.Range(-2f, 2f));
    var rb = b.AddComponent<Rigidbody>(); rb.mass = 1f;
    n++; if (counter) counter.text = "Balls spawned: " + n;
  }
  public void ResetScene() { SceneManager.LoadScene(SceneManager.GetActiveScene().name); }
}
