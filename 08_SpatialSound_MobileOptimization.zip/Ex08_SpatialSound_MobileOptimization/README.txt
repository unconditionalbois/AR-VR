Ex08_SpatialSound_MobileOptimization
=====================
HOW TO OPEN
1. Unzip this file.
2. Unity Hub > Add > Add project from disk > select the unzipped folder "Ex08_SpatialSound_MobileOptimization".
3. Open with Unity 6000.2.10f1 (or any Unity 6 version; accept the upgrade prompt if shown).
4. First open takes a few minutes (packages download). The scene is then AUTO-GENERATED in Assets/Scenes/.
   If it does not appear: top menu AR-VR Practical > Rebuild ... Scene.
5. Open the scene and press Play.

NOTES
A speaker cube orbits you and plays a generated 440 Hz tone with spatialBlend=1 (put on headphones, press Play). Menu: AR-VR Practical > Apply Mobile Optimizations.
