using UnityEditor; using UnityEngine;
public static class MobileOptimizer {
  [MenuItem("AR-VR Practical/Apply Mobile Optimizations")]
  public static void Apply() {
    QualitySettings.shadows = ShadowQuality.Disable;
    QualitySettings.antiAliasing = 0;
    QualitySettings.vSyncCount = 0;
    QualitySettings.pixelLightCount = 1;
    PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android, UnityEditor.ScriptingImplementation.IL2CPP);
    PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
    Debug.Log("Mobile optimizations applied (no shadows, no MSAA, IL2CPP ARM64).");
  }
}
