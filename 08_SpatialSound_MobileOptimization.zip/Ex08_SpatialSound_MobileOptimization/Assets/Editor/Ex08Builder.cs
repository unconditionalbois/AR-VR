using UnityEngine; using UnityEditor; using UnityEditor.SceneManagement; using System.IO;

[InitializeOnLoad]
public static class Ex08Builder {
  const string ScenePath = "Assets/Scenes/Ex08_SpatialSound.unity";
  static Ex08Builder() {
    EditorApplication.delayCall += () => {
      if (EditorApplication.isPlayingOrWillChangePlaymode) return;
      if (!File.Exists(ScenePath)) Build();
    };
  }
  [MenuItem("AR-VR Practical/Rebuild Ex08_SpatialSound Scene")]
  public static void Build() {
    Util.Folder("Assets/Scenes");
    var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

    Util.Prim(PrimitiveType.Plane, "Floor", Vector3.zero, new Vector3(2,1,2), new Color(.5f,.5f,.5f));
    var spk = Util.Prim(PrimitiveType.Cube, "Acoustic_Speaker_01", new Vector3(5,1,0), new Vector3(.6f,1,.6f), Color.black);
    spk.AddComponent<AudioSource>(); spk.AddComponent<SpatialSound>(); spk.AddComponent<Orbit>();
    Camera.main.transform.position = new Vector3(0,1.6f,0);
    Camera.main.gameObject.AddComponent<MobilePerformance>();
    MobileOptimizer.Apply();

    EditorSceneManager.SaveScene(scene, ScenePath);
    Util.AddToBuild(ScenePath);
    AssetDatabase.Refresh();
    Debug.Log("Ex08_SpatialSound scene created: " + ScenePath);
  }
}
