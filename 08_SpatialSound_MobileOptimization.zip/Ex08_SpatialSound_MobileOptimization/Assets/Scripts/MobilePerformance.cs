using UnityEngine;
public class MobilePerformance : MonoBehaviour {
  float dt;
  void Awake() { Application.targetFrameRate = 60; QualitySettings.vSyncCount = 0; }
  void Update() { dt += (Time.unscaledDeltaTime - dt) * 0.1f; }
  void OnGUI() { GUI.Label(new Rect(10, 10, 300, 30), string.Format("FPS: {0:0}", 1f / dt)); }
}
