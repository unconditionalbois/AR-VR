using UnityEngine;
[RequireComponent(typeof(AudioSource))]
public class SpatialSound : MonoBehaviour {
  void Start() {
    var src = GetComponent<AudioSource>();
    src.spatialBlend = 1f;               // 1 = fully 3D
    src.minDistance = 2f; src.maxDistance = 25f;
    src.rolloffMode = AudioRolloffMode.Logarithmic;
    src.loop = true;
    if (src.clip == null) src.clip = MakeTone(440f, 1f);
    src.Play();
  }
  AudioClip MakeTone(float freq, float seconds) {
    int rate = 44100; var data = new float[(int)(rate * seconds)];
    for (int i = 0; i < data.Length; i++) data[i] = 0.3f * Mathf.Sin(2 * Mathf.PI * freq * i / rate);
    var clip = AudioClip.Create("Tone", data.Length, 1, rate, false); clip.SetData(data, 0); return clip;
  }
}
