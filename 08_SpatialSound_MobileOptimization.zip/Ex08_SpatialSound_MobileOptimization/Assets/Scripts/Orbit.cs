using UnityEngine;
public class Orbit : MonoBehaviour {
  public float radius = 5f, speed = 40f;
  void Update() { float a = Time.time * speed * Mathf.Deg2Rad; transform.position = new Vector3(Mathf.Cos(a) * radius, 1f, Mathf.Sin(a) * radius); }
}
