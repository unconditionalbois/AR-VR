using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public static class Builder
{
    static Vector2 V(float x, float y) { return new Vector2(x, y); }

    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex07 VR Interactive Objects UI", "com.hicas.arvr.ex07");
        KitXR.SetupXR(false, true);
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.45f, 0.47f, 0.52f));
        var floorM = Kit.Mat("WorkshopFloor", new Color(0.28f, 0.28f, 0.3f), 0.1f, 0.4f);
        var wallM = Kit.Mat("WorkshopWall", new Color(0.62f, 0.64f, 0.58f), 0f, 0.2f);
        var ceilM = Kit.Mat("GalleryCeiling", new Color(0.2f, 0.2f, 0.24f), 0f, 0.1f);
        var wood = Kit.Mat("TableWood", new Color(0.45f, 0.3f, 0.18f), 0f, 0.4f);
        var metal = Kit.Mat("Metal", new Color(0.55f, 0.57f, 0.6f), 0.9f, 0.7f);

        GameObject floor;
        KitContent.Room(-5, 5, -4, 4, 3.5f, floorM, wallM, ceilM, out floor);
        var l1 = Kit.MakeLight("Directional Light", LightType.Directional, Color.white, 0.5f, Vector3.zero, new Vector3(60, -20, 0));
        var l2 = Kit.MakeLight("Workshop Light A", LightType.Point, new Color(1f, 0.95f, 0.85f), 1.4f, new Vector3(-2, 3, 0), Vector3.zero, LightShadows.None, 9);
        var l3 = Kit.MakeLight("Workshop Light B", LightType.Point, new Color(1f, 0.95f, 0.85f), 1.4f, new Vector3(2, 3, 0), Vector3.zero, LightShadows.None, 9);

        var hud = Kit.MakeCanvas("Desktop Hint", false, V(1920, 1080));
        var hintT = Kit.Label(hud.transform, "Hint", "", 30, Color.white, V(0.05f, 0.01f), V(0.95f, 0.08f));
        var rig = KitXR.BuildVRRig(new Vector3(0, 0, -2.8f), hintT);
        KitXR.TeleportArea(floor, rig.provider);

        // VR UI
        var panel = KitContent.VRPanel("VR Interaction Panel", new Vector3(-2.6f, 1.5f, -0.8f), new Vector3(0, 1.6f, -2.8f), V(900, 720));
        var bg = Kit.Panel(panel.transform, "Background", V(0, 0), V(1, 1), Kit.Panel1);
        Kit.Label(bg, "Title", "VR INTERACTION PANEL v1.0", 52, Color.white, V(0, 0.86f), V(1, 0.98f), TextAnchor.MiddleCenter, FontStyle.Bold);
        var sel = Kit.Label(bg, "Selected Text", "Selected Object: none", 40, new Color(1f, 0.85f, 0.4f), V(0.03f, 0.62f), V(0.97f, 0.84f));
        var bReset = Kit.Btn(bg, "Button_Reset", "RESET SCENE", V(0.08f, 0.40f), V(0.92f, 0.58f), Kit.Accent, 42);
        var bSet = Kit.Btn(bg, "Button_Settings", "SETTINGS (LIGHTS)", V(0.08f, 0.21f), V(0.92f, 0.37f), Kit.Warn1, 40);
        var bExit = Kit.Btn(bg, "Button_Exit", "EXIT", V(0.08f, 0.04f), V(0.92f, 0.18f), Kit.Bad, 42);
        Kit.EventSys(true);

        // Door + physical button
        var door = Kit.Prim(PrimitiveType.Cube, "Door", new Vector3(4.9f, 1.3f, 0.5f), new Vector3(0.2f, 2.6f, 1.8f), Kit.Mat("DoorMat", new Color(0.35f, 0.1f, 0.1f), 0.4f, 0.4f));
        var dc = door.AddComponent<DoorController>(); dc.openOffset = new Vector3(0, 2.7f, 0);
        dc.sfx = KitXR.AddSfx(door, "Success.wav");
        Kit.Prim(PrimitiveType.Cube, "Button Base", new Vector3(4.85f, 1.3f, -1.4f), new Vector3(0.1f, 0.4f, 0.4f), metal);
        var cap = Kit.Prim(PrimitiveType.Cylinder, "Interactive Button", new Vector3(4.75f, 1.3f, -1.4f), new Vector3(0.22f, 0.04f, 0.22f), Kit.Mat("ButtonCap", new Color(0.9f, 0.2f, 0.2f), 0, 0.6f, new Color(0.5f, 0.05f, 0.05f)), null, true, new Vector3(0, 0, 90));
        var lamp = Kit.Prim(PrimitiveType.Sphere, "Button Lamp", new Vector3(4.8f, 1.7f, -1.4f), Vector3.one * 0.1f, Kit.Mat("Lamp", Color.red, 0, 0.6f, new Color(0.6f, 0, 0)), null, false);
        var pb = cap.AddComponent<PressButton>(); pb.door = dc; pb.cap = cap.transform; pb.lamp = lamp.GetComponent<Renderer>();
        var simple = R.Add(cap, "XRSimpleInteractable");
        Kit.AddVoid(simple, "selectEntered", pb, "Press");

        // Workbench, shelf, tools
        Kit.Prim(PrimitiveType.Cube, "Workbench", new Vector3(0, 0.45f, 1.6f), new Vector3(3.2f, 0.9f, 1f), wood);
        Kit.Prim(PrimitiveType.Cube, "Shelf Board 1", new Vector3(-3.5f, 1.0f, 3.7f), new Vector3(2.4f, 0.08f, 0.5f), wood);
        Kit.Prim(PrimitiveType.Cube, "Shelf Board 2", new Vector3(-3.5f, 1.7f, 3.7f), new Vector3(2.4f, 0.08f, 0.5f), wood);
        Kit.Prim(PrimitiveType.Cube, "Table Side", new Vector3(-3.6f, 0.4f, -1.0f), new Vector3(1.2f, 0.8f, 1.2f), wood);

        var click = KitXR.AddSfx(floor, "Click.wav");
        Color[] cols = { new Color(0.9f, 0.2f, 0.2f), new Color(0.2f, 0.7f, 0.3f), new Color(0.2f, 0.4f, 0.95f), new Color(0.95f, 0.8f, 0.2f) };
        for (int i = 0; i < 4; i++)
        {
            var c = Kit.Prim(PrimitiveType.Cube, "grabbableCube " + (i + 1), new Vector3(-1.1f + i * 0.5f, 1.0f, 1.6f), Vector3.one * 0.22f, Kit.Mat("Grab" + i, cols[i], 0.1f, 0.6f));
            KitXR.Grabbable(c, "Cube " + (i + 1), sel, click);
        }
        var ball = Kit.Prim(PrimitiveType.Sphere, "grabbableBall", new Vector3(1.2f, 1.02f, 1.6f), Vector3.one * 0.25f, Kit.Mat("BallPurple", new Color(0.6f, 0.3f, 0.9f), 0.3f, 0.8f));
        KitXR.Grabbable(ball, "Ball", sel, click);
        var tool = Kit.Prim(PrimitiveType.Cylinder, "grabbableTool", new Vector3(1.6f, 1.0f, 1.6f), new Vector3(0.08f, 0.15f, 0.08f), metal);
        KitXR.Grabbable(tool, "Tool", sel, click);
        var tool2 = Kit.Prim(PrimitiveType.Capsule, "grabbableCapsule", new Vector3(-3.6f, 0.95f, -1.0f), new Vector3(0.18f, 0.18f, 0.18f), Kit.Mat("CapsuleOrange", new Color(1f, 0.5f, 0.1f), 0.1f, 0.6f));
        KitXR.Grabbable(tool2, "Capsule", sel, click);

        var ws = new GameObject("Workshop Logic").AddComponent<VRWorkshop>();
        ws.selectedText = sel; ws.door = dc; ws.lights = new[] { l2, l3, l1 };
        Kit.Click(bReset, ws, "ResetScene"); Kit.Click(bSet, ws, "ToggleLights"); Kit.Click(bExit, ws, "ExitApp");
        string p = Kit.SaveScene(sc, "VR_Interactive_Workshop");
        Kit.SetBuildScenes(p);
        return p;
    }
}
