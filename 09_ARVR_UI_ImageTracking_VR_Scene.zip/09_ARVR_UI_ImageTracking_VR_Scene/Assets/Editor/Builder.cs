using UnityEditor;
using UnityEngine;

public static class Builder
{
    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex09 ARVR UI ImageTracking VR Scene", "com.hicas.arvr.ex09");
        KitXR.SetupXR(true, true);
        string menu = KitContent.SceneMenu("MainMenu", "AR / VR PRACTICAL - EX 09",
            "UI Menu  |  Input Modules  |  AR Poster Demo  |  VR Gallery Escape Room",
            new[] { "AR DEMO - Museum Poster / Card", "VR DEMO - Gallery Escape Room", "QUIT" },
            new[] { "AR_Museum_Poster", "VR_Gallery_EscapeRoom", "QUIT" },
            "<b>What is inside</b>\n- Main menu with AR / VR / Back buttons\n- AR image tracking: museum poster + gallery card\n- VR gallery & escape room (grab key, unlock door)\n- Touch / mouse UI (Standalone input module)\n- XR UI input module for VR controllers");
        string ar = KitContent.SceneAR("AR_Museum_Poster", "AR MUSEUM POSTER / CARD DEMO", false, true, 2, true, "MainMenu");
        string vr = KitContent.SceneGallery("VR_Gallery_EscapeRoom", "MainMenu");
        Kit.SetBuildScenes(menu, ar, vr);
        return menu;
    }
}
