using UnityEngine; using UnityEditor; using UnityEditor.SceneManagement; using System.IO;

[InitializeOnLoad]
public static class Ex01Builder {
  const string ScenePath = "Assets/Scenes/Ex01_UnityBasics.unity";
  static Ex01Builder() {
    EditorApplication.delayCall += () => {
      if (EditorApplication.isPlayingOrWillChangePlaymode) return;
      if (!File.Exists(ScenePath)) Build();
    };
  }
  [MenuItem("AR-VR Practical/Rebuild Ex01_UnityBasics Scene")]
  public static void Build() {
    Util.Folder("Assets/Scenes");
    var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

    Util.Prim(PrimitiveType.Plane, "Plane", Vector3.zero, new Vector3(1.5f,1,1.5f), new Color(.6f,.6f,.6f));
    var cube = Util.Prim(PrimitiveType.Cube, "Cube", new Vector3(0,.5f,0), Vector3.one, Color.red);
    cube.AddComponent<Rotator>();
    Util.Prim(PrimitiveType.Sphere, "Sphere", new Vector3(2,.5f,0), Vector3.one, Color.blue);
    // Prefab: save a cube as a prefab, then drop 3 instances in the scene
    Util.Folder("Assets/Prefabs");
    var tmp = Util.Prim(PrimitiveType.Cube, "MyPrefabCube", Vector3.zero, Vector3.one * .6f, Color.green);
    tmp.AddComponent<Rotator>();
    var prefab = PrefabUtility.SaveAsPrefabAsset(tmp, "Assets/Prefabs/MyPrefabCube.prefab");
    Object.DestroyImmediate(tmp);
    for (int i = 0; i < 3; i++) {
      var inst = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
      inst.transform.position = new Vector3(-2 - i * 1.2f, .3f, 1.5f);
    }

    EditorSceneManager.SaveScene(scene, ScenePath);
    Util.AddToBuild(ScenePath);
    AssetDatabase.Refresh();
    Debug.Log("Ex01_UnityBasics scene created: " + ScenePath);
  }
}
