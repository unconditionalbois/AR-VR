using UnityEngine;
public class InteractiveObject : MonoBehaviour {
  void Start() { Debug.Log("Platform: " + Application.platform + " | Object: " + name); }
  void OnMouseDown() { GetComponent<Renderer>().material.color = Random.ColorHSV(); }
  void Update() { transform.Rotate(0, 30 * Time.deltaTime, 0); }
}
