using UnityEngine; using Unity.XR.CoreUtils;
public static class XrRig {
  public static XROrigin Create(Vector3 pos, float camHeight = 1.6f){
    var origin = new GameObject("XR Origin"); origin.transform.position = pos;
    var xr = origin.AddComponent<XROrigin>();
    var off = new GameObject("Camera Offset"); off.transform.SetParent(origin.transform, false);
    var cam = Camera.main;
    if (cam == null){ var g = new GameObject("Main Camera"); g.tag = "MainCamera"; cam = g.AddComponent<Camera>(); g.AddComponent<AudioListener>(); }
    cam.transform.SetParent(off.transform, false); cam.transform.localPosition = new Vector3(0, camHeight, 0); cam.transform.localRotation = Quaternion.identity;
    xr.Origin = origin; xr.CameraFloorOffsetObject = off; xr.Camera = cam;
    return xr;
  }
}
