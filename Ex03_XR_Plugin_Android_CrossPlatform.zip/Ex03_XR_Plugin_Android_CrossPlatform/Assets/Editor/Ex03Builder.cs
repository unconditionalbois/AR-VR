using UnityEngine; using UnityEditor; using UnityEditor.SceneManagement; using System.IO;

[InitializeOnLoad]
public static class Ex03Builder {
  const string ScenePath = "Assets/Scenes/Ex03_XR_CrossPlatform.unity";
  static Ex03Builder() {
    EditorApplication.delayCall += () => {
      if (EditorApplication.isPlayingOrWillChangePlaymode) return;
      if (!File.Exists(ScenePath)) Build();
    };
  }
  [MenuItem("AR-VR Practical/Rebuild Ex03_XR_CrossPlatform Scene")]
  public static void Build() {
    Util.Folder("Assets/Scenes");
    var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

    XrRig.Create(new Vector3(0,0,-3));
    Util.Prim(PrimitiveType.Plane, "Plane", Vector3.zero, new Vector3(1,1,1), new Color(.5f,.5f,.5f));
    var cube = Util.Prim(PrimitiveType.Cube, "RedCube_Interactive", new Vector3(-1,.5f,0), Vector3.one, Color.red);
    cube.AddComponent<InteractiveObject>();
    var sph = Util.Prim(PrimitiveType.Sphere, "BlueSphere_Physics", new Vector3(1,2,0), Vector3.one, Color.blue);
    sph.AddComponent<Rigidbody>();

    EditorSceneManager.SaveScene(scene, ScenePath);
    Util.AddToBuild(ScenePath);
    AssetDatabase.Refresh();
    Debug.Log("Ex03_XR_CrossPlatform scene created: " + ScenePath);
  }
}
