EXERCISE 05: Image Tracking Demo, AR UI Integration
Course: 25MCP20TP - Augmented Reality and Virtual Reality (T & P), MCA
Unity version: Unity 6.3 LTS (6000.3.24f1 / 6000.3.x)  -  Built-in Render Pipeline

REQUIRED PACKAGES (declared in Packages/manifest.json, installed automatically by Unity)
  - 
AR Foundation 6.3.3  - Google ARCore XR Plugin 6.3.3  - XR Plug-in Management 4.5.4  - XR Interaction Toolkit 3.2.0  - OpenXR Plugin 1.16.1  - Input System 1.14.0  - Unity UI (ugui) 2.0.0

HOW TO OPEN
  Unity Hub > Add > Add project from disk > select this folder > open with a Unity 6.3 LTS (6000.3.x) editor.
  On the first open the project automatically generates all of its scenes, prefabs, materials, meshes,
  UI and (where used) the Reference Image Library, and configures XR Plug-in Management and Player settings.
  A "Project ready" dialog appears and the main scene is opened. (Menu AR-VR Practical > Rebuild Project Content
  regenerates everything if ever needed.)

SCENE TO OPEN
  Assets/Scenes/AR_Image_Tracking.unity  (opened automatically)

HOW TO RUN
  Press Play and click SIMULATE DETECTION to see the content. For real AR: build to an ARCore Android phone and point the camera at TargetImages_PrintMe/AR_Museum_Poster.png.

ANDROID REQUIREMENTS
  ARCore-supported Android phone (Android 8.0 / API 26+) with image-tracking support, Google Play Services for AR, USB debugging on, Android Build Support module installed. Show the target image (TargetImages_PrintMe/AR_Museum_Poster.png) on a second screen or print it ~20 cm wide.

VR HARDWARE REQUIREMENTS
  None.
