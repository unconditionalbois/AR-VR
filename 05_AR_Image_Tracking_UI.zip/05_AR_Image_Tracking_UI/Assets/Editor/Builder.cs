using UnityEditor;
using UnityEngine;

public static class Builder
{
    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex05 AR Image Tracking UI", "com.hicas.arvr.ex05");
        KitXR.SetupXR(true, false);
        string p = KitContent.SceneAR("AR_Image_Tracking", "AR IMAGE TRACKING & UI", false, true, 1, false);
        Kit.SetBuildScenes(p);
        return p;
    }
}
