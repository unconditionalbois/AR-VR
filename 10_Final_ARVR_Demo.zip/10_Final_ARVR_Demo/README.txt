EXERCISE 10: Presentation, Demo Day, Final Touches
Course: 25MCP20TP - Augmented Reality and Virtual Reality (T & P), MCA
Unity version: Unity 6.3 LTS (6000.3.24f1 / 6000.3.x)  -  Built-in Render Pipeline

REQUIRED PACKAGES (declared in Packages/manifest.json, installed automatically by Unity)
  - 
AR Foundation 6.3.3  - Google ARCore XR Plugin 6.3.3  - XR Plug-in Management 4.5.4  - XR Interaction Toolkit 3.2.0  - OpenXR Plugin 1.16.1  - Input System 1.14.0  - Unity UI (ugui) 2.0.0

HOW TO OPEN
  Unity Hub > Add > Add project from disk > select this folder > open with a Unity 6.3 LTS (6000.3.x) editor.
  On the first open the project automatically generates all of its scenes, prefabs, materials, meshes,
  UI and (where used) the Reference Image Library, and configures XR Plug-in Management and Player settings.
  A "Project ready" dialog appears and the main scene is opened. (Menu AR-VR Practical > Rebuild Project Content
  regenerates everything if ever needed.)

SCENE TO OPEN
  Assets/Scenes/Main_Menu.unity  (opened automatically)

HOW TO RUN
  Press Play on Main_Menu and choose AR Experience, VR Showcase or the Demo Day Presentation. Back buttons return to the menu.

ANDROID REQUIREMENTS
  ARCore-supported Android phone for the AR experience (target images in TargetImages_PrintMe/). VR showcase runs on PC with a headset; on a phone it falls back to a touch preview.

VR HARDWARE REQUIREMENTS
  For the VR showcase: OpenXR-capable PC VR headset with controllers. Without one: desktop preview.
