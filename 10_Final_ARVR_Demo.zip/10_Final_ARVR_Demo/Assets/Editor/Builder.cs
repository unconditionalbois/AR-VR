using UnityEditor;
using UnityEngine;

public static class Builder
{
    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex10 Final ARVR Demo", "com.hicas.arvr.ex10");
        KitXR.SetupXR(true, true);
        string menu = KitContent.SceneMenu("Main_Menu", "AR / VR FINAL DEMO",
            "Presentation  |  Demo Day  |  Final Touches",
            new[] { "AR EXPERIENCE (Planes + Image Tracking)", "VR SHOWCASE (Teleport + Grab + Sound)", "DEMO DAY PRESENTATION", "QUIT" },
            new[] { "AR_Experience", "VR_Showcase", "Presentation", "QUIT" },
            "<b>Features</b>\n- AR plane detection\n- AR object placement\n- AR image tracking + UI\n- VR XR Origin + controllers\n- Teleportation\n- Interactive VR objects\n- VR UI panel\n- Spatial 3D sound\n- Final menu + slides");
        string ar = KitContent.SceneAR("AR_Experience", "AR EXPERIENCE: PLANES + IMAGE TRACKING", true, true, 2, true, "Main_Menu");
        string vr = KitContent.SceneVRShowcase("VR_Showcase", "Main_Menu");
        string[] titles = {
            "AR / VR Practical - Final Demo", "Objective", "Methodology", "Features Implemented", "AR Implementation",
            "VR Implementation", "Results (Ex 01 - 10)", "Demo Checklist & Thank You" };
        string[] bodies = {
            "25MCP20TP - Augmented Reality and Virtual Reality (T & P)\n\nMaster of Computer Applications\nHindusthan College of Arts & Science (Autonomous), Coimbatore\n\nBuilt with Unity 6.3 LTS",
            "- Learn Unity basics: GameObjects, Components, Prefabs\n- Build interactive physics + UI scenes\n- Develop AR apps with AR Foundation (ARCore)\n- Develop VR apps with XR Interaction Toolkit\n- Add spatial audio and optimise for mobile",
            "1. Install Unity Hub + Unity 6.3 LTS\n2. Configure XR Plug-in Management (ARCore / OpenXR)\n3. Build AR scenes: plane detection, raycast placement, image tracking\n4. Build VR scenes: XR Origin, teleportation, grab interaction\n5. Integrate UI, spatial sound, menus; test and polish",
            "- AR plane detection + tap-to-place objects\n- AR image tracking with reference image library\n- AR UI: info panels, status text, buttons\n- VR rig, controllers, teleportation\n- Grabbable objects and VR UI\n- 3D spatial audio (min / max distance, rolloff)\n- Main menu and scene navigation",
            "- AR Session + XR Origin (AR) + AR Camera\n- ARPlaneManager + ARRaycastManager\n- ARTrackedImageManager + XRReferenceImageLibrary\n- Tracked content: 3D object + world-space info panel\n- Screen-space UI for status and controls",
            "- XR Origin (VR) with HMD + controller pose drivers\n- XR Ray / Direct Interactors\n- Teleportation Area / Anchor + Teleportation Provider\n- XR Grab Interactable objects\n- World-space UI with XR UI Input Module\n- Spatial AudioSource (spatialBlend = 1)",
            "Ex 01  Unity basics, prefabs\nEx 02  Physics + UI\nEx 03  XR plug-in, cross-platform scene\nEx 04  AR plane placement\nEx 05  Image tracking + AR UI\nEx 06  VR rig + teleportation\nEx 07  VR interaction + UI\nEx 08  Spatial sound + optimisation\nEx 09  AR/VR menus + demos\nEx 10  Final demo",
            "Before the demo: charge devices, print / display the museum poster, check ARCore device, connect headset.\n\nThank you!" };
        string pr = KitContent.ScenePresentation("Presentation", titles, bodies, "Main_Menu");
        Kit.SetBuildScenes(menu, ar, vr, pr);
        return menu;
    }
}
