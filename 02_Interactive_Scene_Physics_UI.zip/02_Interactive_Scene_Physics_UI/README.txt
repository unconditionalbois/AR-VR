EXERCISE 02: Create Interactive Scene, Physics, UI Basics
Course: 25MCP20TP - Augmented Reality and Virtual Reality (T & P), MCA
Unity version: Unity 6.3 LTS (6000.3.24f1 / 6000.3.x)  -  Built-in Render Pipeline

REQUIRED PACKAGES (declared in Packages/manifest.json, installed automatically by Unity)
  - 
Input System 1.14.0  - Unity UI (ugui) 2.0.0 (plus built-in modules)

HOW TO OPEN
  Unity Hub > Add > Add project from disk > select this folder > open with a Unity 6.3 LTS (6000.3.x) editor.
  On the first open the project automatically generates all of its scenes, prefabs, materials, meshes,
  UI and (where used) the Reference Image Library, and configures XR Plug-in Management and Player settings.
  A "Project ready" dialog appears and the main scene is opened. (Menu AR-VR Practical > Rebuild Project Content
  regenerates everything if ever needed.)

SCENE TO OPEN
  Assets/Scenes/Physics_Interactive_Scene.unity  (opened automatically)

HOW TO RUN
  Press Play. Click objects to push them, use the sliders and buttons (spawn, explode, gravity, reset).

ANDROID REQUIREMENTS
  None (desktop project).

VR HARDWARE REQUIREMENTS
  None.
