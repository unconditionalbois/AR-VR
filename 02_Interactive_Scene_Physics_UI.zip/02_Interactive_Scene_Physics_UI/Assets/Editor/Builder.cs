using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public static class Builder
{
    static Vector2 V(float x, float y) { return new Vector2(x, y); }

    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex02 Interactive Scene Physics UI", "com.hicas.arvr.ex02");
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.55f, 0.6f, 0.7f), Kit.Sky(new Color(0.45f, 0.65f, 0.95f), new Color(0.4f, 0.4f, 0.4f)));
        Kit.MakeLight("Directional Light", LightType.Directional, Color.white, 1.1f, Vector3.zero, new Vector3(50, -35, 0), LightShadows.Soft);
        var center = Kit.Empty("Camera Target", new Vector3(0, 1, 1));
        var cam = Kit.SimpleCamera(new Vector3(0, 7, -14), new Vector3(25, 0, 0), Color.black, true);
        var oc = cam.gameObject.AddComponent<OrbitCamera>(); oc.target = center.transform; oc.distance = 15f;

        var bouncy = new PhysicsMaterial("Bouncy");
        bouncy.bounciness = 0.8f; bouncy.dynamicFriction = 0.3f; bouncy.staticFriction = 0.3f; bouncy.bounceCombine = PhysicsMaterialCombine.Maximum;
        Kit.Folder("Assets/Materials");
        AssetDatabase.CreateAsset(bouncy, "Assets/Materials/Bouncy.asset");

        var env = Kit.Empty("Environment", Vector3.zero);
        Kit.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(3, 1, 3), Kit.Mat("Ground", new Color(0.42f, 0.5f, 0.42f), 0, 0.1f), env.transform);
        var stone = Kit.Mat("Concrete", new Color(0.6f, 0.6f, 0.62f), 0, 0.2f);
        Kit.Prim(PrimitiveType.Cube, "Ramp", new Vector3(-5.5f, 1.6f, 0), new Vector3(7f, 0.3f, 4f), stone, env.transform, true, new Vector3(0, 0, -20));
        for (int i = 0; i < 5; i++)
            Kit.Prim(PrimitiveType.Cube, "Step " + (i + 1), new Vector3(5f + i * 1.0f, 0.25f * (i + 1), -3f), new Vector3(1f, 0.5f * (i + 1), 2.5f), stone, env.transform);

        var crateM = Kit.Mat("Crate", new Color(0.62f, 0.42f, 0.22f), 0, 0.2f);
        var sphereM = Kit.Mat("Blue", new Color(0.2f, 0.45f, 0.95f), 0.3f, 0.8f);
        var phys = Kit.Empty("Physics Objects", Vector3.zero);
        for (int x = 0; x < 4; x++)
            for (int y = 0; y < 4; y++)
            {
                var c = Kit.Prim(PrimitiveType.Cube, "Crate " + x + "-" + y, new Vector3(-2 + x * 1.05f, 0.5f + y * 1.02f, 6f), Vector3.one, crateM, phys.transform);
                var rb = c.AddComponent<Rigidbody>(); rb.mass = 1f;
            }
        for (int i = 0; i < 3; i++)
        {
            var s = Kit.Prim(PrimitiveType.Sphere, "Bouncy Ball " + (i + 1), new Vector3(-7f + i * 0.3f, 6f + i * 1.5f, -1f + i), Vector3.one, sphereM, phys.transform);
            var rb = s.AddComponent<Rigidbody>(); rb.mass = 0.8f; s.GetComponent<Collider>().sharedMaterial = bouncy;
        }
        var heavy = Kit.Prim(PrimitiveType.Sphere, "Heavy Ball", new Vector3(0, 8f, 1f), Vector3.one * 1.4f, Kit.Mat("Steel", new Color(0.5f, 0.5f, 0.55f), 0.9f, 0.8f), phys.transform);
        heavy.AddComponent<Rigidbody>().mass = 8f;

        var cv = Kit.MakeCanvas("UI Canvas", false, V(1920, 1080));
        Kit.EventSys(false);
        var panel = Kit.Panel(cv.transform, "Control Panel", V(0.76f, 0.04f), V(0.99f, 0.97f), Kit.Panel1);
        Kit.Img(panel, "Header Image", V(0, 0.91f), V(1, 1), Kit.Accent);
        Kit.Label(panel, "Title", "PHYSICS CONTROLS", 40, Color.white, V(0, 0.91f), V(1, 1), TextAnchor.MiddleCenter, FontStyle.Bold);
        var info = Kit.Label(panel, "Info Text", "", 28, Color.white, V(0, 0.64f), V(1, 0.90f), TextAnchor.UpperLeft);
        var pp = new GameObject("Physics Manager").AddComponent<PhysicsPlayground>();
        pp.infoText = info; pp.cubeMat = crateM; pp.sphereMat = sphereM; pp.bouncy = bouncy; pp.spawnRoot = phys.transform;
        Kit.Label(panel, "Mass Label", "Mass of new objects (kg)", 26, Color.white, V(0, 0.57f), V(1, 0.63f));
        pp.massSlider = Kit.MakeSlider(panel, "Mass Slider", V(0.05f, 0.52f), V(0.95f, 0.57f), 0.2f, 10f, 1f);
        Kit.SliderBind(pp.massSlider, pp, "SetMass");
        Kit.Label(panel, "Force Label", "Push / explosion force", 26, Color.white, V(0, 0.45f), V(1, 0.51f));
        pp.forceSlider = Kit.MakeSlider(panel, "Force Slider", V(0.05f, 0.40f), V(0.95f, 0.45f), 1f, 30f, 8f);
        var names = new[] { "SPAWN CUBE", "SPAWN SPHERE", "EXPLODE", "TOGGLE GRAVITY", "RESET SCENE" };
        var meth = new[] { "SpawnCube", "SpawnSphere", "Explode", "ToggleGravity", "ResetScene" };
        var cols = new[] { Kit.Good, Kit.Good, Kit.Warn1, Kit.Accent, Kit.Bad };
        for (int i = 0; i < 5; i++)
        {
            float y1 = 0.36f - i * 0.07f;
            var b = Kit.Btn(panel, names[i], names[i], V(0.06f, y1 - 0.06f), V(0.94f, y1), cols[i], 32);
            Kit.Click(b, pp, meth[i]);
        }
        Kit.Label(cv.transform, "Help", "EX 02 - Interactive scene: click objects to push them. Right-drag = orbit, wheel = zoom.", 30, Color.white, V(0.05f, 0.92f), V(0.70f, 0.99f), TextAnchor.MiddleLeft, FontStyle.Bold);
        string p = Kit.SaveScene(sc, "Physics_Interactive_Scene");
        Kit.SetBuildScenes(p);
        return p;
    }
}
