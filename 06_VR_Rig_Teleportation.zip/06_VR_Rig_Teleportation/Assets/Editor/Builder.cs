using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public static class Builder
{
    static Vector2 V(float x, float y) { return new Vector2(x, y); }

    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex06 VR Rig Teleportation", "com.hicas.arvr.ex06");
        KitXR.SetupXR(false, true);
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.4f, 0.42f, 0.5f));
        var floorM = Kit.Mat("VRFloor", new Color(0.22f, 0.24f, 0.3f), 0.1f, 0.6f);
        var wallM = Kit.Mat("VRWall", new Color(0.6f, 0.64f, 0.74f), 0f, 0.2f);
        var ceilM = Kit.Mat("GalleryCeiling", new Color(0.2f, 0.2f, 0.24f), 0f, 0.1f);
        var platM = Kit.Mat("Platform", new Color(0.5f, 0.5f, 0.55f), 0.1f, 0.4f);
        var padM = Kit.Mat("PadGlow", new Color(0.2f, 0.9f, 1f), 0f, 0.5f, new Color(0.1f, 0.6f, 0.8f));
        var gemM = Kit.Mat("GemCrystal", new Color(0.35f, 0.8f, 1f), 0.2f, 0.9f, new Color(0.1f, 0.5f, 0.9f));

        GameObject floor;
        KitContent.Room(-9, 9, -9, 9, 5, floorM, wallM, ceilM, out floor);
        Kit.MakeLight("Directional Light", LightType.Directional, Color.white, 0.6f, Vector3.zero, new Vector3(55, -30, 0));
        Kit.MakeLight("Point A", LightType.Point, new Color(1, 0.9f, 0.8f), 1.3f, new Vector3(-4, 4f, 2), Vector3.zero, LightShadows.None, 12);
        Kit.MakeLight("Point B", LightType.Point, new Color(0.8f, 0.9f, 1f), 1.3f, new Vector3(4, 4f, 2), Vector3.zero, LightShadows.None, 12);

        var hud = Kit.MakeCanvas("Desktop Hint", false, V(1920, 1080));
        Kit.EventSys(true);
        var hintT = Kit.Label(hud.transform, "Hint", "", 30, Color.white, V(0.05f, 0.01f), V(0.95f, 0.08f));
        var rig = KitXR.BuildVRRig(new Vector3(0, 0, -6), hintT);
        KitXR.TeleportArea(floor, rig.provider);

        // platforms (Teleportation Areas) and pads (Teleportation Anchors + TeleportPoint script from the record)
        Vector3[] plat = { new Vector3(-5, 0.25f, 2), new Vector3(5, 0.25f, 2), new Vector3(0, 0.75f, 7) };
        Vector3[] size = { new Vector3(3, 0.5f, 3), new Vector3(3, 0.5f, 3), new Vector3(3, 1.5f, 3) };
        string[] names = { "PLATFORM A", "PLATFORM B", "PLATFORM C" };
        var tps = new TeleportPoint[4];
        for (int i = 0; i < 3; i++)
        {
            var pf = Kit.Prim(PrimitiveType.Cube, "Platform " + (char)('A' + i), plat[i], size[i], platM);
            KitXR.TeleportArea(pf, rig.provider);
            float top = plat[i].y + size[i].y / 2f;
            var pad = Kit.Prim(PrimitiveType.Cylinder, "Teleport Pad " + (char)('A' + i), new Vector3(plat[i].x, top + 0.02f, plat[i].z), new Vector3(1.2f, 0.02f, 1.2f), padM, null, false);
            tps[i + 1] = pad.AddComponent<TeleportPoint>(); tps[i + 1].player = rig.origin.transform;
            var gem = Kit.MeshObj("Gem " + i, Kit.GemMesh("Gem"), gemM, new Vector3(plat[i].x, top + 1.0f, plat[i].z + 1.0f), Vector3.one * 0.35f, null);
            var fs = gem.AddComponent<FloatSpin>(); fs.bobHeight = 0.08f;
        }
        var start = Kit.Prim(PrimitiveType.Cylinder, "Start Pad", new Vector3(0, 0.02f, -6), new Vector3(1.2f, 0.02f, 1.2f), padM, null, false);
        tps[0] = start.AddComponent<TeleportPoint>(); tps[0].player = rig.origin.transform;

        for (int i = 0; i < 4; i++)
        {
            var pil = Kit.Prim(PrimitiveType.Cylinder, "Pillar " + i, new Vector3(i < 2 ? -8f : 8f, 2.5f, i % 2 == 0 ? -7f : 7f), new Vector3(0.8f, 2.5f, 0.8f), wallM);
        }

        // VR UI panel with teleport buttons
        var panel = KitContent.VRPanel("Teleport Menu", new Vector3(0, 1.5f, -3.4f), new Vector3(0, 1.6f, -6f), V(900, 640));
        var bg = Kit.Panel(panel.transform, "Background", V(0, 0), V(1, 1), Kit.Panel1);
        Kit.Label(bg, "Title", "VR TELEPORTATION", 56, Color.white, V(0, 0.84f), V(1, 0.98f), TextAnchor.MiddleCenter, FontStyle.Bold);
        Kit.Label(bg, "Help", "Aim a controller ray at the floor, a platform or a glowing pad and press + release the trigger to teleport.\nOr use the buttons below.", 32, new Color(0.7f, 0.95f, 1f), V(0.03f, 0.52f), V(0.97f, 0.84f));
        string[] bl = { "START", "PLATFORM A", "PLATFORM B", "PLATFORM C" };
        for (int i = 0; i < 4; i++)
        {
            float x0 = 0.04f + (i % 2) * 0.48f; float y1 = 0.48f - (i / 2) * 0.24f;
            var b = Kit.Btn(bg, "Button " + bl[i], bl[i], V(x0, y1 - 0.2f), V(x0 + 0.44f, y1), i == 0 ? Kit.Good : Kit.Accent, 40);
            Kit.Click(b, tps[i], "TeleportPlayer");
        }
        string p = Kit.SaveScene(sc, "VR_Teleportation_Scene");
        Kit.SetBuildScenes(p);
        return p;
    }
}
