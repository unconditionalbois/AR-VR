EXERCISE 06: VR Setup (Oculus/PC), Add VR Rig, Teleportation
Course: 25MCP20TP - Augmented Reality and Virtual Reality (T & P), MCA
Unity version: Unity 6.3 LTS (6000.3.24f1 / 6000.3.x)  -  Built-in Render Pipeline

REQUIRED PACKAGES (declared in Packages/manifest.json, installed automatically by Unity)
  - 
AR Foundation 6.3.3  - Google ARCore XR Plugin 6.3.3  - XR Plug-in Management 4.5.4  - XR Interaction Toolkit 3.2.0  - OpenXR Plugin 1.16.1  - Input System 1.14.0  - Unity UI (ugui) 2.0.0

HOW TO OPEN
  Unity Hub > Add > Add project from disk > select this folder > open with a Unity 6.3 LTS (6000.3.x) editor.
  On the first open the project automatically generates all of its scenes, prefabs, materials, meshes,
  UI and (where used) the Reference Image Library, and configures XR Plug-in Management and Player settings.
  A "Project ready" dialog appears and the main scene is opened. (Menu AR-VR Practical > Rebuild Project Content
  regenerates everything if ever needed.)

SCENE TO OPEN
  Assets/Scenes/VR_Teleportation_Scene.unity  (opened automatically)

HOW TO RUN
  Put on the headset, press Play, aim a controller ray at the floor/platforms/pads and press+release the trigger to teleport (or use the panel buttons).

ANDROID REQUIREMENTS
  Not used (PC VR project).

VR HARDWARE REQUIREMENTS
  OpenXR-capable PC VR headset with controllers (e.g. Meta Quest via Link/Air Link or SteamVR) and the OpenXR runtime set as active. Without a headset: desktop preview (WASD, right-mouse look, click floor to teleport).
