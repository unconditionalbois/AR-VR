EXERCISE 04: AR Camera Setup, Place Objects on Planes
Course: 25MCP20TP - Augmented Reality and Virtual Reality (T & P), MCA
Unity version: Unity 6.3 LTS (6000.3.24f1 / 6000.3.x)  -  Built-in Render Pipeline

REQUIRED PACKAGES (declared in Packages/manifest.json, installed automatically by Unity)
  - 
AR Foundation 6.3.3  - Google ARCore XR Plugin 6.3.3  - XR Plug-in Management 4.5.4  - XR Interaction Toolkit 3.2.0  - OpenXR Plugin 1.16.1  - Input System 1.14.0  - Unity UI (ugui) 2.0.0

HOW TO OPEN
  Unity Hub > Add > Add project from disk > select this folder > open with a Unity 6.3 LTS (6000.3.x) editor.
  On the first open the project automatically generates all of its scenes, prefabs, materials, meshes,
  UI and (where used) the Reference Image Library, and configures XR Plug-in Management and Player settings.
  A "Project ready" dialog appears and the main scene is opened. (Menu AR-VR Practical > Rebuild Project Content
  regenerates everything if ever needed.)

SCENE TO OPEN
  Assets/Scenes/AR_Plane_Placement.unity  (opened automatically)

HOW TO RUN
  Press Play for the desktop preview (click the grid floor to place the gem). For real AR: File > Build Profiles > Android > Switch Platform > Build And Run on an ARCore phone, move the phone to detect a surface and tap to place.

ANDROID REQUIREMENTS
  ARCore-supported Android phone (Android 8.0 / API 26+), Google Play Services for AR installed, USB debugging on, Android Build Support module installed.

VR HARDWARE REQUIREMENTS
  None.
