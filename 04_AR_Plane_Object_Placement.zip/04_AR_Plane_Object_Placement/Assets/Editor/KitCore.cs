// ============================================================================
//  KitCore - shared Editor-side generator helpers (primitives, materials, UI, scenes).
//  Used by Builder.cs to create every asset, prefab and scene automatically.
// ============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

/// <summary>Small reflection helper so optional package APIs can never break compilation.</summary>
public static class R
{
    static readonly Dictionary<string, Type> cache = new Dictionary<string, Type>();
    const BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

    public static Type T(string name)
    {
        if (cache.TryGetValue(name, out var found) && found != null) return found;
        Type result = null;
        foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
        {
            Type[] ts;
            try { ts = a.GetTypes(); }
            catch (ReflectionTypeLoadException e) { ts = e.Types.Where(x => x != null).ToArray(); }
            catch { continue; }
            foreach (var x in ts)
            {
                if (x.FullName == name) { result = x; break; }
                if (result == null && name.IndexOf('.') < 0 && x.Name == name) result = x;
            }
            if (result != null && result.FullName == name) break;
        }
        cache[name] = result;
        return result;
    }

    public static Component Add(GameObject g, string typeName)
    {
        var t = T(typeName);
        if (t == null) { Kit.Warn("Type not found: " + typeName); return null; }
        return g.AddComponent(t);
    }

    static object Conv(Type t, object v)
    {
        if (v == null) return null;
        if (t.IsEnum && !v.GetType().IsEnum) return v is string s ? Enum.Parse(t, s) : Enum.ToObject(t, v);
        return v;
    }

    public static bool Set(object o, string n, object v)
    {
        if (o == null) return false;
        var t = o.GetType();
        var p = t.GetProperty(n, BF);
        if (p != null && p.CanWrite)
        {
            try { p.SetValue(o, Conv(p.PropertyType, v)); return true; }
            catch (Exception e) { Kit.Warn(t.Name + "." + n + " set failed: " + e.Message); return false; }
        }
        var f = t.GetField(n, BF);
        if (f != null)
        {
            try { f.SetValue(o, Conv(f.FieldType, v)); return true; }
            catch (Exception e) { Kit.Warn(t.Name + "." + n + " set failed: " + e.Message); return false; }
        }
        Kit.Warn(t.Name + "." + n + " not found");
        return false;
    }

    public static object Get(object o, string n)
    {
        if (o == null) return null;
        var t = o.GetType();
        var p = t.GetProperty(n, BF);
        if (p != null && p.CanRead) { try { return p.GetValue(o); } catch { } }
        var f = t.GetField(n, BF);
        if (f != null) return f.GetValue(o);
        return null;
    }

    public static object Call(object o, string n, params object[] a)
    {
        if (o == null) return null;
        foreach (var m in o.GetType().GetMethods(BF).Where(x => x.Name == n && x.GetParameters().Length == a.Length))
        {
            try { return m.Invoke(o, a); } catch (ArgumentException) { } catch (InvalidOperationException) { } catch (TargetInvocationException e) { Kit.Warn(n + " threw: " + e.InnerException?.Message); return null; }
        }
        Kit.Warn("Method not found: " + o.GetType().Name + "." + n);
        return null;
    }

    public static object CallStatic(Type t, string n, params object[] a)
    {
        if (t == null) return null;
        foreach (var m in t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static).Where(x => x.Name == n && x.GetParameters().Length == a.Length))
        {
            try { return m.Invoke(null, a); } catch (ArgumentException) { } catch (InvalidOperationException) { } catch (TargetInvocationException e) { Kit.Warn(n + " threw: " + e.InnerException?.Message); return null; }
        }
        Kit.Warn("Static method not found: " + t.Name + "." + n);
        return null;
    }
}

public static class Kit
{
    public static int Warnings;
    public static void Warn(string msg) { Warnings++; Debug.LogWarning("[AR/VR Setup] " + msg); }
    public static void Log(string msg) { Debug.Log("[AR/VR Setup] " + msg); }

    // ------------------------------------------------------------------ folders / assets
    public static void Folder(string path)
    {
        path = path.TrimEnd('/');
        if (AssetDatabase.IsValidFolder(path)) return;
        string parent = Path.GetDirectoryName(path).Replace('\\', '/');
        if (!string.IsNullOrEmpty(parent) && parent != "Assets") Folder(parent);
        AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
    }

    public static Texture2D Tex(string file)
    {
        string p = "Assets/Textures/" + file;
        var t = AssetDatabase.LoadAssetAtPath<Texture2D>(p);
        if (t == null) { AssetDatabase.ImportAsset(p, ImportAssetOptions.ForceUpdate); t = AssetDatabase.LoadAssetAtPath<Texture2D>(p); }
        if (t == null) Warn("Missing texture " + p);
        return t;
    }

    public static void ConfigureTexture(string file, int maxSize, bool repeat, bool mips)
    {
        string p = "Assets/Textures/" + file;
        var ti = AssetImporter.GetAtPath(p) as TextureImporter;
        if (ti == null) return;
        ti.maxTextureSize = maxSize;
        ti.wrapMode = repeat ? TextureWrapMode.Repeat : TextureWrapMode.Clamp;
        ti.mipmapEnabled = mips;
        ti.alphaIsTransparency = true;
        ti.SaveAndReimport();
    }

    public static AudioClip Clip(string file)
    {
        string p = "Assets/Audio/" + file;
        var c = AssetDatabase.LoadAssetAtPath<AudioClip>(p);
        if (c == null) { AssetDatabase.ImportAsset(p, ImportAssetOptions.ForceUpdate); c = AssetDatabase.LoadAssetAtPath<AudioClip>(p); }
        if (c == null) Warn("Missing audio " + p);
        return c;
    }

    public static void ConfigureAudio(string file, bool mono)
    {
        var ai = AssetImporter.GetAtPath("Assets/Audio/" + file) as AudioImporter;
        if (ai == null) return;
        ai.forceToMono = mono;
        var s = ai.defaultSampleSettings;
        s.loadType = AudioClipLoadType.DecompressOnLoad;
        s.compressionFormat = AudioCompressionFormat.ADPCM;
        ai.defaultSampleSettings = s;
        ai.SaveAndReimport();
    }

    // ------------------------------------------------------------------ materials
    public static Material Mat(string name, Color c, float metallic = 0f, float smooth = 0.35f, Color? emission = null,
                               bool transparent = false, Texture tex = null, string shader = "Standard")
    {
        Folder("Assets/Materials");
        string path = "Assets/Materials/" + name + ".mat";
        var sh = Shader.Find(shader);
        if (sh == null) { Warn("Shader not found: " + shader); sh = Shader.Find("Standard"); }
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null) { m = new Material(sh); AssetDatabase.CreateAsset(m, path); }
        m.shader = sh;
        m.color = c;
        if (tex != null) m.mainTexture = tex;
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
        if (emission.HasValue && shader == "Standard")
        {
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", emission.Value);
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
        }
        if (transparent && shader == "Standard")
        {
            m.SetFloat("_Mode", 3);
            m.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.DisableKeyword("_ALPHATEST_ON");
            m.EnableKeyword("_ALPHABLEND_ON");
            m.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            m.renderQueue = 3000;
        }
        EditorUtility.SetDirty(m);
        return m;
    }

    public static Material SprMat(string name, Color c, Texture tex)
    {
        return Mat(name, c, 0, 0, null, false, tex, "Sprites/Default");
    }

    public static Material Sky(Color tint, Color ground)
    {
        Folder("Assets/Materials");
        string path = "Assets/Materials/Sky.mat";
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null) { m = new Material(Shader.Find("Skybox/Procedural")); AssetDatabase.CreateAsset(m, path); }
        m.SetColor("_SkyTint", tint);
        m.SetColor("_GroundColor", ground);
        m.SetFloat("_AtmosphereThickness", 0.9f);
        m.SetFloat("_Exposure", 1.1f);
        EditorUtility.SetDirty(m);
        return m;
    }

    // ------------------------------------------------------------------ primitives / meshes
    public static GameObject Prim(PrimitiveType t, string name, Vector3 pos, Vector3 scale, Material m = null,
                                  Transform parent = null, bool collider = true, Vector3? euler = null)
    {
        var g = GameObject.CreatePrimitive(t);
        g.name = name;
        if (parent != null) g.transform.SetParent(parent, false);
        g.transform.localPosition = pos;
        g.transform.localScale = scale;
        if (euler.HasValue) g.transform.localEulerAngles = euler.Value;
        if (m != null) g.GetComponent<Renderer>().sharedMaterial = m;
        if (!collider) { var c = g.GetComponent<Collider>(); if (c != null) Object.DestroyImmediate(c); }
        return g;
    }

    public static GameObject Empty(string name, Vector3 pos, Transform parent = null)
    {
        var g = new GameObject(name);
        if (parent != null) g.transform.SetParent(parent, false);
        g.transform.localPosition = pos;
        return g;
    }

    public static GameObject MeshObj(string name, Mesh mesh, Material m, Vector3 pos, Vector3 scale, Transform parent, bool collider = false)
    {
        var g = new GameObject(name);
        if (parent != null) g.transform.SetParent(parent, false);
        g.transform.localPosition = pos;
        g.transform.localScale = scale;
        g.AddComponent<MeshFilter>().sharedMesh = mesh;
        g.AddComponent<MeshRenderer>().sharedMaterial = m;
        if (collider) g.AddComponent<MeshCollider>().convex = true;
        return g;
    }

    public static Mesh TorusMesh(string name, float bigR, float tubeR, int seg = 40, int sides = 14)
    {
        Folder("Assets/Meshes");
        string path = "Assets/Meshes/" + name + ".asset";
        var existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if (existing != null) return existing;
        var v = new List<Vector3>(); var n = new List<Vector3>(); var uv = new List<Vector2>(); var tri = new List<int>();
        for (int i = 0; i <= seg; i++)
        {
            float a = i * Mathf.PI * 2f / seg;
            for (int j = 0; j <= sides; j++)
            {
                float b = j * Mathf.PI * 2f / sides;
                v.Add(new Vector3((bigR + tubeR * Mathf.Cos(b)) * Mathf.Cos(a), tubeR * Mathf.Sin(b), (bigR + tubeR * Mathf.Cos(b)) * Mathf.Sin(a)));
                n.Add(new Vector3(Mathf.Cos(b) * Mathf.Cos(a), Mathf.Sin(b), Mathf.Cos(b) * Mathf.Sin(a)));
                uv.Add(new Vector2((float)i / seg, (float)j / sides));
            }
        }
        for (int i = 0; i < seg; i++)
            for (int j = 0; j < sides; j++)
            {
                int a = i * (sides + 1) + j, b = (i + 1) * (sides + 1) + j;
                tri.Add(a); tri.Add(a + 1); tri.Add(b);
                tri.Add(a + 1); tri.Add(b + 1); tri.Add(b);
            }
        var m = new Mesh { name = name };
        m.SetVertices(v); m.SetNormals(n); m.SetUVs(0, uv); m.SetTriangles(tri, 0);
        m.RecalculateBounds();
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    public static Mesh GemMesh(string name)
    {
        Folder("Assets/Meshes");
        string path = "Assets/Meshes/" + name + ".asset";
        var existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if (existing != null) return existing;
        int k = 8; float r = 0.5f, yg = 0.12f, top = 0.34f, bot = -0.62f;
        var v = new List<Vector3>(); var tri = new List<int>();
        Func<int, Vector3> g = i => new Vector3(Mathf.Cos(i * Mathf.PI * 2f / k) * r, yg, Mathf.Sin(i * Mathf.PI * 2f / k) * r);
        for (int i = 0; i < k; i++)
        {
            int s = v.Count;
            v.Add(new Vector3(0, top, 0)); v.Add(g(i + 1)); v.Add(g(i));
            tri.Add(s); tri.Add(s + 1); tri.Add(s + 2);
            s = v.Count;
            v.Add(new Vector3(0, bot, 0)); v.Add(g(i)); v.Add(g(i + 1));
            tri.Add(s); tri.Add(s + 1); tri.Add(s + 2);
        }
        var m = new Mesh { name = name };
        m.SetVertices(v); m.SetTriangles(tri, 0);
        m.RecalculateNormals(); m.RecalculateBounds();
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    public static Light MakeLight(string name, LightType type, Color col, float intensity, Vector3 pos, Vector3 euler, LightShadows sh = LightShadows.None, float range = 10f, Transform parent = null)
    {
        var g = new GameObject(name);
        if (parent != null) g.transform.SetParent(parent, false);
        g.transform.position = pos;
        g.transform.eulerAngles = euler;
        var l = g.AddComponent<Light>();
        l.type = type; l.color = col; l.intensity = intensity; l.shadows = sh; l.range = range;
        return l;
    }

    // ------------------------------------------------------------------ scenes / prefabs
    public static Scene NewScene() { return EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single); }

    public static string SaveScene(Scene s, string name)
    {
        Folder("Assets/Scenes");
        string p = "Assets/Scenes/" + name + ".unity";
        EditorSceneManager.SaveScene(s, p);
        return p;
    }

    public static void Env(Color ambient, Material sky = null)
    {
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = ambient;
        RenderSettings.skybox = sky;
        RenderSettings.fog = false;
        DynamicGI.UpdateEnvironment();
    }

    public static GameObject SavePrefab(GameObject root, string name)
    {
        Folder("Assets/Prefabs");
        string p = "Assets/Prefabs/" + name + ".prefab";
        var pf = PrefabUtility.SaveAsPrefabAsset(root, p);
        Object.DestroyImmediate(root);
        return pf;
    }

    public static GameObject Inst(GameObject prefab, Vector3 pos, Vector3? euler = null, Transform parent = null, string name = null)
    {
        var g = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
        if (parent != null) g.transform.SetParent(parent, false);
        g.transform.position = pos;
        if (euler.HasValue) g.transform.eulerAngles = euler.Value;
        if (name != null) g.name = name;
        return g;
    }

    public static Camera SimpleCamera(Vector3 pos, Vector3 euler, Color bg, bool skybox)
    {
        var g = new GameObject("Main Camera") { tag = "MainCamera" };
        g.transform.position = pos; g.transform.eulerAngles = euler;
        var c = g.AddComponent<Camera>();
        c.clearFlags = skybox ? CameraClearFlags.Skybox : CameraClearFlags.SolidColor;
        c.backgroundColor = bg; c.nearClipPlane = 0.1f; c.farClipPlane = 200f;
        g.AddComponent<AudioListener>();
        return c;
    }

    public static void EventSys(bool xr)
    {
        var g = new GameObject("EventSystem");
        g.AddComponent<EventSystem>();
        Type t = xr ? R.T("XRUIInputModule") : null;
        if (t != null) g.AddComponent(t); else g.AddComponent<StandaloneInputModule>();
    }

    // ------------------------------------------------------------------ serialized-property helpers
    public static bool SetObj(Object target, string prop, Object val)
    {
        if (target == null) return false;
        var so = new SerializedObject(target); var p = so.FindProperty(prop);
        if (p == null) { Warn(target.GetType().Name + "." + prop + " not found"); return false; }
        p.objectReferenceValue = val; so.ApplyModifiedPropertiesWithoutUndo(); return true;
    }
    public static bool SetInt(Object target, string prop, int v)
    {
        if (target == null) return false;
        var so = new SerializedObject(target); var p = so.FindProperty(prop);
        if (p == null) { Warn(target.GetType().Name + "." + prop + " not found"); return false; }
        if (p.propertyType == SerializedPropertyType.Enum) p.enumValueFlag = v; else p.intValue = v;
        so.ApplyModifiedPropertiesWithoutUndo(); return true;
    }
    public static bool SetBool(Object target, string prop, bool v)
    {
        if (target == null) return false;
        var so = new SerializedObject(target); var p = so.FindProperty(prop);
        if (p == null) { Warn(target.GetType().Name + "." + prop + " not found"); return false; }
        p.boolValue = v; so.ApplyModifiedPropertiesWithoutUndo(); return true;
    }

    /// <summary>Fills every empty object-reference field of 'target' with a matching candidate (by declared type name).</summary>
    public static void AutoWire(Component target, params Component[] cands)
    {
        if (target == null) return;
        var so = new SerializedObject(target);
        var it = so.GetIterator();
        bool enter = true;
        while (it.NextVisible(enter))
        {
            enter = false;
            if (it.propertyType != SerializedPropertyType.ObjectReference || it.objectReferenceValue != null) continue;
            var m = Regex.Match(it.type, @"PPtr<\$?(.+)>");
            if (!m.Success) continue;
            string want = m.Groups[1].Value;
            bool done = false;
            foreach (var c in cands)
            {
                if (c == null || done) continue;
                for (var t = c.GetType(); t != null && !done; t = t.BaseType)
                    if (t.Name == want) { it.objectReferenceValue = c; done = true; }
            }
        }
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    /// <summary>Binds an XRInputButtonReader-style struct property to an InputActionReference (name-agnostic).</summary>
    public static bool SetReader(Object target, string prop, UnityEngine.InputSystem.InputActionReference r)
    {
        if (target == null || r == null) return false;
        var so = new SerializedObject(target); var p = so.FindProperty(prop);
        if (p == null) { Warn(target.GetType().Name + "." + prop + " not found (input binding skipped)"); return false; }
        var mode = p.FindPropertyRelative("m_InputSourceMode");
        if (mode != null) mode.enumValueFlag = 1;
        bool any = false;
        var it = p.Copy(); var end = p.GetEndProperty();
        bool next = it.Next(true);
        while (next && !SerializedProperty.EqualContents(it, end))
        {
            if (it.propertyType == SerializedPropertyType.ObjectReference && it.type.Contains("InputActionReference"))
            { it.objectReferenceValue = r; any = true; }
            next = it.Next(true);
        }
        so.ApplyModifiedPropertiesWithoutUndo();
        if (!any) Warn(target.GetType().Name + "." + prop + " has no InputActionReference slot");
        return any;
    }

    // persistent event listeners -------------------------------------------------
    public static void AddVoid(Component comp, string eventName, Object target, string method)
    {
        if (comp == null || target == null) return;
        var ev = R.Get(comp, eventName) as UnityEventBase;
        if (ev == null) { Warn("Event not found: " + comp.GetType().Name + "." + eventName); return; }
        var mi = target.GetType().GetMethod(method, BindingFlags.Public | BindingFlags.Instance, null, Type.EmptyTypes, null);
        if (mi == null) { Warn("Method not found: " + method); return; }
        UnityEventTools.AddVoidPersistentListener(ev, (UnityAction)Delegate.CreateDelegate(typeof(UnityAction), target, mi));
    }

    public static void Click(Button b, Object target, string method)
    {
        var mi = target.GetType().GetMethod(method, BindingFlags.Public | BindingFlags.Instance, null, Type.EmptyTypes, null);
        if (mi == null) { Warn("Click method not found: " + target.GetType().Name + "." + method); return; }
        UnityEventTools.AddPersistentListener(b.onClick, (UnityAction)Delegate.CreateDelegate(typeof(UnityAction), target, mi));
    }

    public static void ClickStr(Button b, Object target, string method, string arg)
    {
        var mi = target.GetType().GetMethod(method, BindingFlags.Public | BindingFlags.Instance, null, new[] { typeof(string) }, null);
        if (mi == null) { Warn("Click(string) method not found: " + target.GetType().Name + "." + method); return; }
        UnityEventTools.AddStringPersistentListener(b.onClick, (UnityAction<string>)Delegate.CreateDelegate(typeof(UnityAction<string>), target, mi), arg);
    }

    public static void SliderBind(Slider s, Object target, string method)
    {
        var mi = target.GetType().GetMethod(method, BindingFlags.Public | BindingFlags.Instance, null, new[] { typeof(float) }, null);
        if (mi == null) { Warn("Slider method not found: " + target.GetType().Name + "." + method); return; }
        UnityEventTools.AddPersistentListener(s.onValueChanged, (UnityAction<float>)Delegate.CreateDelegate(typeof(UnityAction<float>), target, mi));
    }

    // ------------------------------------------------------------------ UI builders
    public static Font UIFont { get { return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } }
    static Sprite BuiltinSprite(string n) { return AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/" + n); }

    public static readonly Color Panel1 = new Color(0.06f, 0.09f, 0.16f, 0.88f);
    public static readonly Color Accent = new Color(0.10f, 0.55f, 0.95f, 1f);
    public static readonly Color Good = new Color(0.12f, 0.65f, 0.40f, 1f);
    public static readonly Color Warn1 = new Color(0.90f, 0.55f, 0.10f, 1f);
    public static readonly Color Bad = new Color(0.80f, 0.22f, 0.25f, 1f);

    public static Canvas MakeCanvas(string name, bool world, Vector2 size, float worldScale = 0.001f, Transform parent = null, int sortOrder = 0)
    {
        var g = new GameObject(name, typeof(RectTransform));
        if (parent != null) g.transform.SetParent(parent, false);
        var c = g.AddComponent<Canvas>();
        var rt = g.GetComponent<RectTransform>();
        if (world)
        {
            c.renderMode = RenderMode.WorldSpace;
            rt.sizeDelta = size;
            rt.localScale = Vector3.one * worldScale;
            g.AddComponent<GraphicRaycaster>();
            g.AddComponent<WorldCanvasSetup>();
        }
        else
        {
            c.renderMode = RenderMode.ScreenSpaceOverlay;
            c.sortingOrder = sortOrder;
            var cs = g.AddComponent<CanvasScaler>();
            cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            cs.referenceResolution = size;
            cs.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            cs.matchWidthOrHeight = 0.5f;
            g.AddComponent<GraphicRaycaster>();
        }
        return c;
    }

    public static RectTransform Panel(Transform parent, string name, Vector2 amin, Vector2 amax, Color col,
                                      Vector2? offMin = null, Vector2? offMax = null, bool rounded = true)
    {
        var g = new GameObject(name, typeof(RectTransform), typeof(Image));
        g.transform.SetParent(parent, false);
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.offsetMin = offMin ?? Vector2.zero; rt.offsetMax = offMax ?? Vector2.zero;
        var im = g.GetComponent<Image>(); im.color = col;
        if (rounded) { im.sprite = BuiltinSprite("UISprite.psd"); im.type = Image.Type.Sliced; }
        return rt;
    }

    public static Text Label(Transform parent, string name, string text, int size, Color col, Vector2 amin, Vector2 amax,
                             TextAnchor align = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Normal,
                             Vector2? offMin = null, Vector2? offMax = null, bool bestFit = true)
    {
        var g = new GameObject(name, typeof(RectTransform), typeof(Text));
        g.transform.SetParent(parent, false);
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.offsetMin = offMin ?? new Vector2(8, 4); rt.offsetMax = offMax ?? new Vector2(-8, -4);
        var t = g.GetComponent<Text>();
        t.font = UIFont; t.text = text; t.fontSize = size; t.color = col; t.alignment = align; t.fontStyle = style;
        t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Truncate;
        t.raycastTarget = false; t.supportRichText = true;
        if (bestFit) { t.resizeTextForBestFit = true; t.resizeTextMinSize = Mathf.Max(8, size / 3); t.resizeTextMaxSize = size; }
        return t;
    }

    public static Button Btn(Transform parent, string name, string text, Vector2 amin, Vector2 amax, Color col, int fontSize = 34,
                             Vector2? offMin = null, Vector2? offMax = null)
    {
        var rt = Panel(parent, name, amin, amax, col, offMin, offMax);
        var b = rt.gameObject.AddComponent<Button>();
        b.targetGraphic = rt.GetComponent<Image>();
        var cb = b.colors;
        cb.normalColor = Color.white; cb.highlightedColor = new Color(0.85f, 0.95f, 1f); cb.pressedColor = new Color(0.6f, 0.7f, 0.8f); cb.selectedColor = Color.white;
        b.colors = cb;
        Label(rt, "Text", text, fontSize, Color.white, Vector2.zero, Vector2.one, TextAnchor.MiddleCenter, FontStyle.Bold);
        return b;
    }

    public static Slider MakeSlider(Transform parent, string name, Vector2 amin, Vector2 amax, float min, float max, float val, bool whole = false,
                                    Vector2? offMin = null, Vector2? offMax = null)
    {
        var res = new DefaultControls.Resources
        {
            standard = BuiltinSprite("UISprite.psd"),
            background = BuiltinSprite("Background.psd"),
            knob = BuiltinSprite("Knob.psd"),
            checkmark = BuiltinSprite("Checkmark.psd")
        };
        var go = DefaultControls.CreateSlider(res);
        go.name = name;
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.offsetMin = offMin ?? Vector2.zero; rt.offsetMax = offMax ?? Vector2.zero;
        var s = go.GetComponent<Slider>();
        s.minValue = min; s.maxValue = max; s.wholeNumbers = whole; s.SetValueWithoutNotify(val);
        return s;
    }

    public static Image Img(Transform parent, string name, Vector2 amin, Vector2 amax, Color col, Sprite sprite = null)
    {
        var rt = Panel(parent, name, amin, amax, col, null, null, false);
        var im = rt.GetComponent<Image>(); im.sprite = sprite; im.raycastTarget = false; return im;
    }

    public static RawImage Raw(Transform parent, string name, Texture tex, Vector2 amin, Vector2 amax)
    {
        var g = new GameObject(name, typeof(RectTransform), typeof(RawImage));
        g.transform.SetParent(parent, false);
        var rt = g.GetComponent<RectTransform>(); rt.anchorMin = amin; rt.anchorMax = amax; rt.offsetMin = rt.offsetMax = Vector2.zero;
        var ri = g.GetComponent<RawImage>(); ri.texture = tex; ri.raycastTarget = false; return ri;
    }

    // ------------------------------------------------------------------ project-level
    public static void SetBuildScenes(params string[] scenePaths)
    {
        EditorBuildSettings.scenes = scenePaths.Select(p => new EditorBuildSettingsScene(p, true)).ToArray();
    }

    public static void StaticFlags(GameObject root)
    {
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
            GameObjectUtility.SetStaticEditorFlags(t.gameObject, StaticEditorFlags.BatchingStatic | StaticEditorFlags.OccluderStatic | StaticEditorFlags.OccludeeStatic);
    }

    public static void PlayerCommon(string productName, string appId)
    {
        PlayerSettings.companyName = "HICAS MCA";
        PlayerSettings.productName = productName;
        try
        {
            var android = UnityEditor.Build.NamedBuildTarget.Android;
            PlayerSettings.SetApplicationIdentifier(android, appId);
            PlayerSettings.SetScriptingBackend(android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
        }
        catch (Exception e) { Warn("Android player settings: " + e.Message); }
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
        PlayerSettings.defaultScreenWidth = 1280;
        PlayerSettings.defaultScreenHeight = 720;
        PlayerSettings.runInBackground = true;
    }
}
