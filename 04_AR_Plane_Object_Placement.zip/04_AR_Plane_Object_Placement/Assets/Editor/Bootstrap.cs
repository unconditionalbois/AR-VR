using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Runs once, automatically, the first time the project is opened and generates every
// asset, prefab, material, Reference Image Library and scene. Then opens the main scene.
[InitializeOnLoad]
public static class Bootstrap
{
    const string Marker = "ProjectSettings/ARVR_Generated.txt";
    static Bootstrap() { EditorApplication.update += Tick; }

    static void Tick()
    {
        if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode) return;
        EditorApplication.update -= Tick;
        if (!File.Exists(Marker)) Run();
    }

    [MenuItem("AR-VR Practical/Rebuild Project Content")]
    static void Rebuild() { Run(); }

    static void Run()
    {
        try
        {
            EditorUtility.DisplayProgressBar("AR/VR Practical", "Generating scenes, prefabs and assets...", 0.3f);
            AssetDatabase.Refresh();
            Kit.Warnings = 0;
            string main = Builder.BuildAll();
            AssetDatabase.SaveAssets();
            File.WriteAllText(Marker, "generated " + DateTime.Now);
            if (!string.IsNullOrEmpty(main)) EditorSceneManager.OpenScene(main);
            Debug.Log("[AR/VR Setup] Project generated. Warnings: " + Kit.Warnings + ". Main scene: " + main + "  -> press Play.");
            EditorUtility.ClearProgressBar();
            if (!Application.isBatchMode)
                EditorUtility.DisplayDialog("Project ready", "All scenes and assets were generated.\nThe main scene is open - press Play.\n\n(Setup warnings: " + Kit.Warnings + " - see Console)", "OK");
        }
        catch (Exception e)
        {
            EditorUtility.ClearProgressBar();
            Debug.LogError("[AR/VR Setup] Generation failed: " + e);
        }
    }
}
