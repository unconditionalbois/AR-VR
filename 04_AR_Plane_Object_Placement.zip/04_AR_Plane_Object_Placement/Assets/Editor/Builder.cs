using UnityEditor;
using UnityEngine;

public static class Builder
{
    public static string BuildAll()
    {
        Kit.PlayerCommon("Ex04 AR Plane Object Placement", "com.hicas.arvr.ex04");
        KitXR.SetupXR(true, false);
        string p = KitContent.SceneAR("AR_Plane_Placement", "AR PLANE DETECTION & OBJECT PLACEMENT", true, false, 0, false);
        Kit.SetBuildScenes(p);
        return p;
    }
}
