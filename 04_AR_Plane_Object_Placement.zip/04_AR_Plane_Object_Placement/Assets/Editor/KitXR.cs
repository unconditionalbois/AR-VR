// ============================================================================
//  KitXR - AR / VR rig builders, Reference Image Library, XR Management setup.
//  Package-specific (XR Interaction Toolkit, XR Management, OpenXR) APIs are
//  accessed through reflection / serialized properties so version differences
//  cannot break compilation; any step that cannot be applied logs a warning.
// ============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Object = UnityEngine.Object;

public class ARRigInfo { public GameObject session, origin; public Camera cam; public ARPlaneManager planes; public ARTrackedImageManager images; }
public class VRRigInfo { public GameObject origin; public Camera cam; public Component provider; }

public static class KitXR
{
    // ------------------------------------------------------------------ input
    public static InputActionAsset InputAsset()
    {
        var a = AssetDatabase.LoadAssetAtPath<InputActionAsset>("Assets/Input/ARVR_Input.inputactions");
        if (a == null) Kit.Warn("Input actions asset missing");
        return a;
    }

    public static InputActionReference Ref(string map, string action)
    {
        Kit.Folder("Assets/Input/Refs");
        string path = "Assets/Input/Refs/" + map + " " + action + ".asset";
        var ex = AssetDatabase.LoadAssetAtPath<InputActionReference>(path);
        if (ex != null) return ex;
        var asset = InputAsset();
        var a = asset != null ? asset.FindAction(map + "/" + action) : null;
        if (a == null) { Kit.Warn("Input action not found: " + map + "/" + action); return null; }
        var r = InputActionReference.Create(a);
        AssetDatabase.CreateAsset(r, path);
        return r;
    }

    public static TrackedPoseDriver Pose(GameObject g, string map)
    {
        var d = g.AddComponent<TrackedPoseDriver>();
        d.positionInput = new InputActionProperty(Ref(map, "Position"));
        d.rotationInput = new InputActionProperty(Ref(map, "Rotation"));
        d.trackingStateInput = new InputActionProperty(Ref(map, "TrackingState"));
        return d;
    }

    // ------------------------------------------------------------------ AR
    public static GameObject MakePlanePrefab()
    {
        Kit.ConfigureTexture("PlaneGrid.png", 256, true, true);
        var mat = Kit.SprMat("ARPlane", new Color(0.2f, 0.9f, 1f, 0.55f), Kit.Tex("PlaneGrid.png"));
        var line = Kit.SprMat("ARPlaneLine", new Color(0.4f, 1f, 1f, 1f), null);
        var g = new GameObject("AR Plane Visual");
        g.AddComponent<MeshFilter>();
        var mr = g.AddComponent<MeshRenderer>();
        mr.sharedMaterial = mat; mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; mr.receiveShadows = false;
        var lr = g.AddComponent<LineRenderer>();
        lr.sharedMaterial = line; lr.widthMultiplier = 0.005f; lr.loop = true; lr.useWorldSpace = false;
        g.AddComponent<MeshCollider>();
        g.AddComponent<ARPlane>();
        if (g.GetComponent<ARPlaneMeshVisualizer>() == null) g.AddComponent<ARPlaneMeshVisualizer>();
        return Kit.SavePrefab(g, "AR Plane Visual");
    }

    public static XRReferenceImageLibrary MakeLibrary(string assetName, string[] names, string[] texFiles, float[] sizesMeters)
    {
        Kit.Folder("Assets/ReferenceImageLibraries");
        string path = "Assets/ReferenceImageLibraries/" + assetName + ".asset";
        if (AssetDatabase.LoadAssetAtPath<Object>(path) != null) AssetDatabase.DeleteAsset(path);
        var lib = ScriptableObject.CreateInstance<XRReferenceImageLibrary>();
        AssetDatabase.CreateAsset(lib, path);
        var ext = R.T("UnityEditor.XR.ARSubsystems.XRReferenceImageLibraryExtensions");
        if (ext == null) { Kit.Warn("XRReferenceImageLibraryExtensions not found"); return lib; }
        for (int i = 0; i < names.Length; i++)
        {
            Kit.ConfigureTexture(texFiles[i], 1024, false, false);
            var tex = Kit.Tex(texFiles[i]);
            int idx = lib.count;
            R.CallStatic(ext, "Add", lib);
            R.CallStatic(ext, "SetName", lib, idx, names[i]);
            R.CallStatic(ext, "SetSpecifySize", lib, idx, true);
            R.CallStatic(ext, "SetSize", lib, idx, new Vector2(sizesMeters[i], sizesMeters[i]));
            R.CallStatic(ext, "SetTexture", lib, idx, tex, true);
        }
        EditorUtility.SetDirty(lib);
        AssetDatabase.SaveAssets();
        if (lib.count != names.Length) Kit.Warn("Reference image library has " + lib.count + " images (expected " + names.Length + ")");
        else Kit.Log("Reference Image Library '" + assetName + "' created with " + lib.count + " image(s).");
        return lib;
    }

    public static ARRigInfo BuildARRig(bool planes, bool images, GameObject planePrefab, XRReferenceImageLibrary lib, GameObject trackedPrefab)
    {
        var info = new ARRigInfo();
        var inputGo = new GameObject("Input Actions");
        inputGo.AddComponent<EnableInputActions>().asset = InputAsset();

        info.session = new GameObject("AR Session");
        info.session.AddComponent<ARSession>();
        info.session.AddComponent<ARInputManager>();

        var origin = new GameObject("XR Origin (AR)");
        var offset = Kit.Empty("Camera Offset", Vector3.zero, origin.transform);
        var camGo = new GameObject("AR Camera") { tag = "MainCamera" };
        camGo.transform.SetParent(offset.transform, false);
        // editor/desktop preview pose (overridden by ARCore on a real device)
        camGo.transform.localPosition = new Vector3(0, 0.55f, -0.45f);
        camGo.transform.localEulerAngles = new Vector3(45, 0, 0);
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(0.10f, 0.13f, 0.20f);
        cam.nearClipPlane = 0.05f; cam.farClipPlane = 30f;
        camGo.AddComponent<AudioListener>();
        camGo.AddComponent<ARCameraManager>();
        camGo.AddComponent<ARCameraBackground>();
        Pose(camGo, "XR Head");
        camGo.AddComponent<DesktopPoseFix>();

        var xro = R.Add(origin, "XROrigin");
        R.Set(xro, "Origin", origin);
        R.Set(xro, "CameraFloorOffsetObject", offset);
        R.Set(xro, "Camera", cam);
        R.Set(xro, "RequestedTrackingOriginMode", "NotSpecified");

        origin.AddComponent<ARRaycastManager>();
        if (planes)
        {
            info.planes = origin.AddComponent<ARPlaneManager>();
            info.planes.planePrefab = planePrefab;
            R.Set(info.planes, "requestedDetectionMode", "Horizontal, Vertical");
        }
        if (images)
        {
            info.images = origin.AddComponent<ARTrackedImageManager>();
            info.images.referenceLibrary = lib;
            R.Set(info.images, "trackedImagePrefab", trackedPrefab);
            R.Set(info.images, "requestedMaxNumberOfMovingImages", 2);
        }
        info.origin = origin; info.cam = cam;
        return info;
    }

    // ------------------------------------------------------------------ VR
    static GameObject MakeController(string name, string map, Transform parent, Material body, Material rayMat)
    {
        var c = Kit.Empty(name, Vector3.zero, parent);
        Pose(c, map);
        Kit.Prim(PrimitiveType.Cube, "Controller Model", new Vector3(0, 0, 0.04f), new Vector3(0.05f, 0.04f, 0.13f), body, c.transform, false);

        var rayGo = Kit.Empty("Ray Interactor", Vector3.zero, c.transform);
        var lr = rayGo.AddComponent<LineRenderer>();
        lr.sharedMaterial = rayMat; lr.widthMultiplier = 0.005f; lr.positionCount = 2;
        var ri = R.Add(rayGo, "XRRayInteractor");
        R.Add(rayGo, "XRInteractorLineVisual");
        Kit.SetReader(ri, "m_SelectInput", Ref(map, "Trigger"));
        Kit.SetReader(ri, "m_UIPressInput", Ref(map, "Trigger"));

        var d = Kit.Empty("Direct Interactor", Vector3.zero, c.transform);
        var sc = d.AddComponent<SphereCollider>(); sc.isTrigger = true; sc.radius = 0.07f;
        var rb = d.AddComponent<Rigidbody>(); rb.isKinematic = true; rb.useGravity = false;
        var di = R.Add(d, "XRDirectInteractor");
        Kit.SetReader(di, "m_SelectInput", Ref(map, "Grip"));
        return c;
    }

    public static VRRigInfo BuildVRRig(Vector3 pos, Text hint)
    {
        var info = new VRRigInfo();
        var imGo = new GameObject("XR Interaction Manager");
        R.Add(imGo, "XRInteractionManager");
        var inp = new GameObject("Input Actions");
        inp.AddComponent<EnableInputActions>().asset = InputAsset();

        var origin = new GameObject("XR Origin (VR)");
        origin.transform.position = pos;
        var offset = Kit.Empty("Camera Offset", Vector3.zero, origin.transform);
        var camGo = new GameObject("Main Camera") { tag = "MainCamera" };
        camGo.transform.SetParent(offset.transform, false);
        camGo.transform.localPosition = new Vector3(0, 1.6f, 0);
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(0.05f, 0.06f, 0.09f);
        cam.nearClipPlane = 0.05f; cam.farClipPlane = 100f;
        camGo.AddComponent<AudioListener>();
        Pose(camGo, "XR Head");

        var xro = R.Add(origin, "XROrigin");
        R.Set(xro, "Origin", origin);
        R.Set(xro, "CameraFloorOffsetObject", offset);
        R.Set(xro, "Camera", cam);
        R.Set(xro, "RequestedTrackingOriginMode", "Floor");

        var body = Kit.Mat("ControllerBody", new Color(0.12f, 0.13f, 0.17f), 0.3f, 0.6f, new Color(0.05f, 0.25f, 0.5f));
        var ray = Kit.SprMat("RayLine", Color.white, null);
        MakeController("Left Controller", "XR LeftHand", offset.transform, body, ray);
        MakeController("Right Controller", "XR RightHand", offset.transform, body, ray);

        var loco = Kit.Empty("Locomotion", Vector3.zero, origin.transform);
        Component med = R.T("LocomotionMediator") != null ? R.Add(loco, "LocomotionMediator") : R.Add(loco, "LocomotionSystem");
        var bt = R.Add(loco, "XRBodyTransformer");
        var tp = R.Add(loco, "TeleportationProvider");
        Kit.AutoWire(med, xro, bt, cam);
        Kit.AutoWire(bt, xro, med);
        Kit.AutoWire(tp, med, xro);

        var np = origin.AddComponent<NoHeadsetPreview>();
        np.origin = origin.transform; np.cam = cam; np.hint = hint;
        info.origin = origin; info.cam = cam; info.provider = tp;
        return info;
    }

    public static Component TeleportArea(GameObject g, Component provider)
    {
        var a = R.Add(g, "TeleportationArea");
        Kit.AutoWire(a, provider);
        return a;
    }

    public static Component TeleportAnchor(GameObject g, Transform anchor, Component provider)
    {
        var a = R.Add(g, "TeleportationAnchor");
        Kit.SetObj(a, "m_TeleportAnchorTransform", anchor);
        Kit.AutoWire(a, provider);
        return a;
    }

    public static GrabbableObject Grabbable(GameObject g, string display, Text info, AudioSource sfx)
    {
        var go = g.AddComponent<GrabbableObject>();
        var rb = g.GetComponent<Rigidbody>(); rb.mass = 0.5f;
        var gi = R.Add(g, "XRGrabInteractable");
        go.displayName = display; go.infoText = info; go.sfx = sfx;
        Kit.AddVoid(gi, "selectEntered", go, "OnGrabbed");
        Kit.AddVoid(gi, "selectExited", go, "OnReleased");
        return go;
    }

    public static void VRCanvas(Canvas c) { R.Add(c.gameObject, "TrackedDeviceGraphicRaycaster"); }

    public static AudioSource AddSfx(GameObject g, string clip)
    {
        var a = g.AddComponent<AudioSource>();
        a.clip = Kit.Clip(clip); a.playOnAwake = false; a.spatialBlend = 1f; a.minDistance = 1f; a.maxDistance = 15f;
        return a;
    }

    // ------------------------------------------------------------------ XR Management
    public static void SetupXR(bool arcoreAndroid, bool openxrStandalone)
    {
        try
        {
            if (arcoreAndroid) Loader(BuildTargetGroup.Android, "UnityEngine.XR.ARCore.ARCoreLoader");
            if (openxrStandalone)
            {
                Loader(BuildTargetGroup.Standalone, "UnityEngine.XR.OpenXR.OpenXRLoader");
                EnableOpenXRProfiles(BuildTargetGroup.Standalone);
            }
        }
        catch (Exception e) { Kit.Warn("XR Plug-in Management setup failed: " + e.Message); }
    }

    static void Loader(BuildTargetGroup group, string loaderType)
    {
        var tPer = R.T("UnityEditor.XR.Management.XRGeneralSettingsPerBuildTarget");
        var tGen = R.T("UnityEngine.XR.Management.XRGeneralSettings");
        var tMan = R.T("UnityEngine.XR.Management.XRManagerSettings");
        var tStore = R.T("UnityEditor.XR.Management.Metadata.XRPackageMetadataStore");
        if (tPer == null || tGen == null || tMan == null || tStore == null) { Kit.Warn("XR Management types not found"); return; }
        const string key = "com.unity.xr.management.loader_settings";
        Kit.Folder("Assets/XR");
        Object per;
        EditorBuildSettings.TryGetConfigObject<Object>(key, out per);
        if (per == null || per.GetType() != tPer)
        {
            per = ScriptableObject.CreateInstance(tPer);
            AssetDatabase.CreateAsset(per, "Assets/XR/XRGeneralSettingsPerBuildTarget.asset");
            EditorBuildSettings.AddConfigObject(key, per, true);
        }
        string perPath = AssetDatabase.GetAssetPath(per);
        var gs = R.Call(per, "SettingsForBuildTarget", group) as Object;
        if (gs == null)
        {
            gs = ScriptableObject.CreateInstance(tGen); gs.name = group + " Settings";
            R.Call(per, "SetSettingsForBuildTarget", group, gs);
            AssetDatabase.AddObjectToAsset(gs, perPath);
        }
        var man = R.Get(gs, "AssignedSettings") as Object;
        if (man == null)
        {
            man = ScriptableObject.CreateInstance(tMan); man.name = group + " Providers";
            AssetDatabase.AddObjectToAsset(man, perPath);
            R.Set(gs, "AssignedSettings", man);
        }
        var ok = R.CallStatic(tStore, "AssignLoader", man, loaderType, group);
        R.Set(gs, "InitManagerOnStart", true);
        EditorUtility.SetDirty(per); EditorUtility.SetDirty(gs); EditorUtility.SetDirty(man);
        AssetDatabase.SaveAssets();
        Kit.Log("XR loader " + loaderType + " for " + group + ": " + (ok is bool && (bool)ok ? "assigned" : "NOT confirmed"));
    }

    static void EnableOpenXRProfiles(BuildTargetGroup g)
    {
        try
        {
            var t = R.T("UnityEngine.XR.OpenXR.OpenXRSettings");
            if (t == null) { Kit.Warn("OpenXRSettings type not found"); return; }
            object s = R.CallStatic(t, "GetSettingsForBuildTargetGroup", g);
            if (s == null)
            {
                var p = t.GetProperty("Instance", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                if (p != null) s = p.GetValue(null);
            }
            if (s == null) { Kit.Warn("OpenXR settings not available - enable a controller profile under Project Settings > XR Plug-in Management > OpenXR"); return; }
            var feats = R.Call(s, "GetFeatures") as System.Collections.IEnumerable;
            int n = 0;
            if (feats != null)
                foreach (var f in feats)
                {
                    if (f == null) continue;
                    if (f.GetType().Name.Contains("Profile")) { R.Set(f, "enabled", true); EditorUtility.SetDirty((Object)f); n++; }
                }
            AssetDatabase.SaveAssets();
            if (n == 0) Kit.Warn("No OpenXR interaction profiles were enabled automatically (enable 'Oculus Touch Controller Profile' under Project Settings > XR Plug-in Management > OpenXR).");
            else Kit.Log("Enabled " + n + " OpenXR interaction profile(s).");
        }
        catch (Exception e) { Kit.Warn("OpenXR profiles: " + e.Message); }
    }
}
