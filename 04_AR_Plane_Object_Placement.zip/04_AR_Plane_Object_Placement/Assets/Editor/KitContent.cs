// ============================================================================
//  KitContent - reusable generated content: prefabs, AR scene, menus, VR rooms.
// ============================================================================
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARSubsystems;
using Object = UnityEngine.Object;

public static class KitContent
{
    static Vector2 V(float x, float y) { return new Vector2(x, y); }
    static readonly Color Gold = new Color(1f, 0.78f, 0.25f);

    // ------------------------------------------------------------------ prefabs
    public static GameObject GemPrefab()
    {
        var gemMesh = Kit.GemMesh("Gem");
        var torus = Kit.TorusMesh("Ring", 0.09f, 0.006f);
        var root = new GameObject("Placed Gem");
        var baseM = Kit.Mat("GemBase", new Color(0.18f, 0.2f, 0.26f), 0.8f, 0.6f);
        var gemM = Kit.Mat("GemCrystal", new Color(0.35f, 0.8f, 1f), 0.2f, 0.9f, new Color(0.1f, 0.5f, 0.9f));
        var goldM = Kit.Mat("Gold", Gold, 1f, 0.7f);
        Kit.Prim(PrimitiveType.Cylinder, "Base", new Vector3(0, 0.01f, 0), new Vector3(0.2f, 0.01f, 0.2f), baseM, root.transform, false);
        var gem = Kit.MeshObj("Crystal", gemMesh, gemM, new Vector3(0, 0.14f, 0), Vector3.one * 0.12f, root.transform);
        var fs = gem.AddComponent<FloatSpin>(); fs.spin = new Vector3(0, 70, 0); fs.bobHeight = 0.01f;
        var ring = Kit.MeshObj("Ring", torus, goldM, new Vector3(0, 0.14f, 0), Vector3.one, root.transform);
        ring.transform.localEulerAngles = new Vector3(25, 0, 0);
        var fr = ring.AddComponent<FloatSpin>(); fr.spin = new Vector3(0, -40, 0);
        for (int i = 0; i < 3; i++)
        {
            var o = Kit.Prim(PrimitiveType.Sphere, "Orbiter " + i, Vector3.zero, Vector3.one * 0.025f, gemM, root.transform, false);
            var ob = o.AddComponent<Orbiter>(); ob.radius = 0.11f; ob.speed = 120f; ob.height = 0.14f; ob.phase = i * 120f;
        }
        var shadow = Kit.SprMat("BlobShadow", new Color(0, 0, 0, 0.5f), Kit.Tex("Disc.png"));
        Kit.Prim(PrimitiveType.Quad, "Shadow", new Vector3(0, 0.002f, 0), new Vector3(0.35f, 0.35f, 1), shadow, root.transform, false, new Vector3(90, 0, 0));
        return Kit.SavePrefab(root, "Placed Gem");
    }

    public static GameObject MuseumContent(string prefabName, string title, string desc, Color accent, bool card)
    {
        var torus = Kit.TorusMesh("Ring", 0.09f, 0.006f);
        var root = new GameObject(prefabName);
        var gold = Kit.Mat("Gold", Gold, 1f, 0.7f);
        var stone = Kit.Mat("Stone", new Color(0.75f, 0.7f, 0.6f), 0f, 0.2f);
        var glow = Kit.Mat("Glow_" + prefabName, accent * 0.9f, 0.3f, 0.8f, accent * 0.8f);
        Kit.Prim(PrimitiveType.Cylinder, "Pedestal", new Vector3(0, 0.025f, 0), new Vector3(0.12f, 0.025f, 0.12f), stone, root.transform, false);
        var art = Kit.Empty("Artifact", new Vector3(0, 0.13f, 0), root.transform);
        var fs = art.AddComponent<FloatSpin>(); fs.bobHeight = 0.01f;
        if (!card)
        {
            fs.spin = new Vector3(0, 50, 0);
            Kit.Prim(PrimitiveType.Sphere, "Golden Orb", Vector3.zero, Vector3.one * 0.09f, gold, art.transform, false);
            var r = Kit.MeshObj("Ring", torus, glow, Vector3.zero, Vector3.one * 1.1f, art.transform);
            r.transform.localEulerAngles = new Vector3(70, 0, 0);
            for (int i = 0; i < 4; i++)
            {
                var o = Kit.Prim(PrimitiveType.Sphere, "Satellite " + i, Vector3.zero, Vector3.one * 0.02f, glow, art.transform, false);
                var ob = o.AddComponent<Orbiter>(); ob.radius = 0.1f; ob.speed = 140f; ob.phase = i * 90f; ob.height = (i % 2 == 0 ? 0.03f : -0.03f);
            }
        }
        else
        {
            fs.spin = new Vector3(30, 60, 0);
            Kit.Prim(PrimitiveType.Cube, "Logo Cube", Vector3.zero, Vector3.one * 0.08f, glow, art.transform, false);
            var r = Kit.MeshObj("Ring", torus, gold, Vector3.zero, Vector3.one, art.transform);
            r.transform.localEulerAngles = new Vector3(0, 0, 40);
        }
        var anchor = Kit.Empty("Info Panel Anchor", new Vector3(0, 0.27f, 0), root.transform);
        anchor.AddComponent<FaceCamera>();
        var cv = Kit.MakeCanvas("Info Canvas", true, V(800, 520), 0.00028f, anchor.transform);
        cv.GetComponent<RectTransform>().localPosition = Vector3.zero;
        var bg = Kit.Panel(cv.transform, "Background", V(0, 0), V(1, 1), Kit.Panel1);
        var tt = Kit.Label(bg, "Title", title, 54, Color.white, V(0, 0.78f), V(1, 0.97f), TextAnchor.MiddleCenter, FontStyle.Bold);
        var st = Kit.Label(bg, "Status", "STATUS: TRACKING", 34, new Color(0.4f, 1f, 0.6f), V(0, 0.64f), V(1, 0.78f));
        var det = Kit.Panel(bg, "Details", V(0.04f, 0.28f), V(0.96f, 0.64f), new Color(1, 1, 1, 0.08f));
        var body = Kit.Label(det, "Body", desc, 30, Color.white, V(0, 0), V(1, 1), TextAnchor.UpperLeft);
        var btn = Kit.Btn(bg, "Info Button", "MORE INFO", V(0.25f, 0.05f), V(0.75f, 0.24f), accent * 0.7f + new Color(0, 0, 0, 0.3f), 38);
        det.gameObject.SetActive(false);
        var ip = anchor.AddComponent<InfoPanelController>();
        ip.titleText = tt; ip.statusText = st; ip.bodyText = body; ip.buttonLabel = btn.GetComponentInChildren<Text>(); ip.details = det.gameObject;
        Kit.Click(btn, ip, "ToggleDetails");
        return Kit.SavePrefab(root, prefabName);
    }

    public static GameObject HolderPrefab()
    {
        var g = new GameObject("TrackedImageHolder");
        g.AddComponent<TrackedImageContent>();
        return Kit.SavePrefab(g, "TrackedImageHolder");
    }

    public static GameObject Speaker(Vector3 pos)
    {
        var root = Kit.Empty("Speaker Object", pos);
        var dark = Kit.Mat("SpeakerBody", new Color(0.08f, 0.08f, 0.1f), 0.3f, 0.5f);
        var cone = Kit.Mat("SpeakerCone", new Color(0.3f, 0.32f, 0.38f), 0.2f, 0.4f);
        var lit = Kit.Mat("SpeakerLed", new Color(0.2f, 1f, 0.5f), 0f, 0.5f, new Color(0.1f, 0.8f, 0.3f));
        Kit.Prim(PrimitiveType.Cube, "Cabinet", new Vector3(0, 0.55f, 0), new Vector3(0.55f, 1.1f, 0.45f), dark, root.transform);
        Kit.Prim(PrimitiveType.Cylinder, "Woofer", new Vector3(0, 0.38f, -0.235f), new Vector3(0.38f, 0.02f, 0.38f), cone, root.transform, false, new Vector3(90, 0, 0));
        Kit.Prim(PrimitiveType.Cylinder, "Tweeter", new Vector3(0, 0.85f, -0.235f), new Vector3(0.16f, 0.02f, 0.16f), cone, root.transform, false, new Vector3(90, 0, 0));
        Kit.Prim(PrimitiveType.Sphere, "Power LED", new Vector3(0.2f, 1.02f, -0.23f), Vector3.one * 0.04f, lit, root.transform, false);
        return root;
    }

    public static AudioSource SpatialSource(GameObject g, float min, float max, float volume)
    {
        var a = g.AddComponent<AudioSource>();
        a.clip = Kit.Clip("Spatial_Hum.wav");
        a.loop = true; a.playOnAwake = true; a.volume = volume;
        a.spatialBlend = 1f; a.minDistance = min; a.maxDistance = max;
        a.rolloffMode = AudioRolloffMode.Logarithmic; a.dopplerLevel = 0.5f;
        g.AddComponent<SpatialSound>();
        return a;
    }

    // ------------------------------------------------------------------ UI helpers
    public static Text TopPanel(Transform canvas, string title, string status)
    {
        var p = Kit.Panel(canvas, "Top Panel", V(0.17f, 0.82f), V(0.83f, 0.98f), Kit.Panel1);
        Kit.Label(p, "Title", title, 44, Color.white, V(0, 0.52f), V(1, 1), TextAnchor.MiddleCenter, FontStyle.Bold);
        return Kit.Label(p, "Status", status, 30, new Color(0.7f, 0.9f, 1f), V(0, 0), V(1, 0.55f));
    }

    public static Button[] BottomRow(Transform parent, string[] labels, Color[] cols, float y0 = 0.03f, float y1 = 0.15f)
    {
        int n = labels.Length; float gap = 0.02f, w = (0.92f - gap * (n - 1)) / n;
        var res = new Button[n];
        for (int i = 0; i < n; i++)
        {
            float x0 = 0.04f + i * (w + gap);
            res[i] = Kit.Btn(parent, "Button " + labels[i], labels[i], V(x0, y0), V(x0 + w, y1), cols[i], 36);
        }
        return res;
    }

    public static Canvas VRPanel(string name, Vector3 pos, Vector3 viewer, Vector2 sizePx, float scale = 0.001f)
    {
        var c = Kit.MakeCanvas(name, true, sizePx, scale);
        c.transform.position = pos;
        Vector3 d = pos - viewer; d.y = 0;
        c.transform.rotation = Quaternion.LookRotation(d);
        KitXR.VRCanvas(c);
        return c;
    }

    public static void Face(Transform t, Vector3 viewer)
    {
        Vector3 d = t.position - viewer; d.y = 0; t.rotation = Quaternion.LookRotation(d);
    }

    public static void Room(float x0, float x1, float z0, float z1, float h, Material floorM, Material wallM, Material ceilM, out GameObject floor)
    {
        float w = x1 - x0, l = z1 - z0, cx = (x0 + x1) / 2f, cz = (z0 + z1) / 2f;
        floor = Kit.Prim(PrimitiveType.Cube, "Floor", new Vector3(cx, -0.05f, cz), new Vector3(w, 0.1f, l), floorM);
        Kit.Prim(PrimitiveType.Cube, "Wall North", new Vector3(cx, h / 2f, z1 + 0.1f), new Vector3(w + 0.4f, h, 0.2f), wallM);
        Kit.Prim(PrimitiveType.Cube, "Wall South", new Vector3(cx, h / 2f, z0 - 0.1f), new Vector3(w + 0.4f, h, 0.2f), wallM);
        Kit.Prim(PrimitiveType.Cube, "Wall East", new Vector3(x1 + 0.1f, h / 2f, cz), new Vector3(0.2f, h, l), wallM);
        Kit.Prim(PrimitiveType.Cube, "Wall West", new Vector3(x0 - 0.1f, h / 2f, cz), new Vector3(0.2f, h, l), wallM);
        Kit.Prim(PrimitiveType.Cube, "Ceiling", new Vector3(cx, h + 0.05f, cz), new Vector3(w + 0.4f, 0.1f, l + 0.4f), ceilM);
    }

    // ------------------------------------------------------------------ AR scene (plane placement and/or image tracking)
    public static string SceneAR(string sceneName, string title, bool planes, bool images, int nImages, bool back, string menuScene = "Main_Menu")
    {
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.65f, 0.65f, 0.7f));
        Kit.MakeLight("Directional Light", LightType.Directional, Color.white, 1.0f, new Vector3(0, 3, 0), new Vector3(50, -30, 0));
        Kit.ConfigureTexture("PlaneGrid.png", 256, true, true);

        GameObject planePrefab = planes ? KitXR.MakePlanePrefab() : null;
        GameObject gem = planes ? GemPrefab() : null;
        UnityEngine.XR.ARSubsystems.XRReferenceImageLibrary lib = null; GameObject holder = null;
        var entries = new List<TrackedImageController.Entry>();
        if (images)
        {
            var names = new List<string> { "AR_Museum_Poster" }; var files = new List<string> { "AR_Museum_Poster.png" };
            if (nImages > 1) { names.Add("AR_Gallery_Card"); files.Add("AR_Gallery_Card.png"); }
            var sizes = new float[names.Count]; for (int i = 0; i < sizes.Length; i++) sizes[i] = 0.2f;
            lib = KitXR.MakeLibrary(nImages > 1 ? "ARVR_ImageLibrary" : "MuseumImageLibrary", names.ToArray(), files.ToArray(), sizes);
            holder = HolderPrefab();
            var c1 = MuseumContent("MuseumContent", "THE GOLDEN ORB", "Ancient artifact, 3D scanned for the AR Museum.\nOrigin: Nile valley.\nAge: ~3,200 years.\nTap MORE INFO again to hide this panel.", new Color(1f, 0.7f, 0.2f), false);
            entries.Add(new TrackedImageController.Entry { imageName = "AR_Museum_Poster", contentPrefab = c1 });
            if (nImages > 1)
            {
                var c2 = MuseumContent("GalleryCardContent", "AR GALLERY CARD", "Virtual business card.\nHICAS MCA - AR/VR Practical\n25MCP20TP. Image tracking + UI.", new Color(0.2f, 0.85f, 0.8f), true);
                entries.Add(new TrackedImageController.Entry { imageName = "AR_Gallery_Card", contentPrefab = c2 });
            }
        }
        var rig = KitXR.BuildARRig(planes, images, planePrefab, lib, holder);

        // editor preview environment (hidden on phones)
        var prev = Kit.Empty("Editor Preview (desktop only)", Vector3.zero); prev.AddComponent<DesktopOnly>();
        var gridM = Kit.Mat("PreviewGrid", new Color(0.25f, 0.6f, 0.9f), 0f, 0.1f, null, false, Kit.Tex("PlaneGrid.png"));
        gridM.mainTextureScale = V(24, 24);
        Kit.Prim(PrimitiveType.Cube, "Editor Preview Floor", new Vector3(0, -0.01f, 0), new Vector3(6, 0.02f, 6), gridM, prev.transform);
        Transform posterT = null;
        if (images)
        {
            var pm = Kit.Mat("PreviewPoster", Color.white, 0, 0.1f, null, false, Kit.Tex("AR_Museum_Poster.png"));
            posterT = Kit.Prim(PrimitiveType.Quad, "Preview Poster", new Vector3(0, 0.003f, 0.05f), new Vector3(0.2f, 0.2f, 1), pm, prev.transform, false, new Vector3(90, 0, 0)).transform;
        }

        var nav = new GameObject("Scene Navigator").AddComponent<SceneNavigator>();
        var cv = Kit.MakeCanvas("AR HUD", false, V(1920, 1080));
        Kit.EventSys(false);
        var status = TopPanel(cv.transform, title, "Starting AR...");
        Text detected = null;
        if (images) detected = Kit.Label(cv.transform, "Detected Label", "Detected: none", 34, Color.white, V(0.3f, 0.70f), V(0.7f, 0.80f));

        var labels = new List<string>(); var cols = new List<Color>(); var acts = new List<Action<Button>>();
        PlaceObjectOnPlane pop = null; TrackedImageController tic = null;
        if (planes)
        {
            pop = rig.origin.AddComponent<PlaceObjectOnPlane>();
            pop.objectToPlace = gem; pop.planeManager = rig.planes; pop.statusText = status;
            var reticle = Kit.Empty("Placement Reticle", Vector3.zero);
            Kit.Prim(PrimitiveType.Quad, "Ring", Vector3.zero, Vector3.one * 0.18f, Kit.SprMat("Reticle", new Color(0.3f, 1f, 0.9f, 0.95f), Kit.Tex("Ring.png")), reticle.transform, false, new Vector3(90, 0, 0));
            pop.indicator = reticle;
            labels.Add("CLEAR"); cols.Add(Kit.Bad); acts.Add(b => Kit.Click(b, pop, "ClearAll"));
            labels.Add("UNDO"); cols.Add(Kit.Warn1); acts.Add(b => Kit.Click(b, pop, "UndoLast"));
            labels.Add("PLANES ON/OFF"); cols.Add(Kit.Accent); acts.Add(b => Kit.Click(b, pop, "TogglePlanes"));
        }
        if (images)
        {
            tic = new GameObject("Image Tracking Controller").AddComponent<TrackedImageController>();
            tic.manager = rig.images; tic.entries = entries.ToArray(); tic.statusText = planes ? null : status; tic.detectedText = detected; tic.previewPoster = posterT;
            var sit = rig.origin.AddComponent<SimpleImageTracking>(); sit.imageManager = rig.images;
            labels.Add("INFO"); cols.Add(Kit.Good); acts.Add(b => Kit.Click(b, tic, "ToggleInfo"));
            labels.Add("RESET SCAN"); cols.Add(Kit.Warn1); acts.Add(b => Kit.Click(b, tic, "ResetScan"));
            if (planes) status.text = "Plane placement + image tracking active";
            var simGroup = new GameObject("Simulate Group (desktop only)", typeof(RectTransform)); simGroup.transform.SetParent(cv.transform, false);
            var sgrt = simGroup.GetComponent<RectTransform>(); sgrt.anchorMin = Vector2.zero; sgrt.anchorMax = Vector2.one; sgrt.offsetMin = sgrt.offsetMax = Vector2.zero;
            simGroup.AddComponent<DesktopOnly>();
            var sim = Kit.Btn(simGroup.transform, "Simulate Detection", "SIMULATE DETECTION (EDITOR PREVIEW)", V(0.30f, 0.17f), V(0.70f, 0.26f), new Color(0.5f, 0.3f, 0.8f), 30);
            Kit.Click(sim, tic, "SimulateDetection");
        }
        var btns = BottomRow(cv.transform, labels.ToArray(), cols.ToArray());
        for (int i = 0; i < btns.Length; i++) acts[i](btns[i]);
        if (back)
        {
            var bb = Kit.Btn(cv.transform, "Back Button", "< MENU", V(0.01f, 0.88f), V(0.14f, 0.98f), Kit.Bad, 34);
            Kit.ClickStr(bb, nav, "Load", menuScene);
        }
        return Kit.SaveScene(sc, sceneName);
    }

    // ------------------------------------------------------------------ main menu
    public static string SceneMenu(string sceneName, string title, string subtitle, string[] labels, string[] targets, string features)
    {
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.35f, 0.38f, 0.5f));
        Kit.MakeLight("Key Light", LightType.Directional, Color.white, 1.1f, Vector3.zero, new Vector3(40, -30, 0));
        var cam = Kit.SimpleCamera(new Vector3(0, 0.5f, -6), Vector3.zero, new Color(0.04f, 0.05f, 0.12f), false);
        var gemMesh = Kit.GemMesh("Gem"); var torus = Kit.TorusMesh("Ring", 0.09f, 0.006f);
        var gemM = Kit.Mat("MenuGem", new Color(0.35f, 0.8f, 1f), 0.2f, 0.9f, new Color(0.1f, 0.5f, 0.9f));
        var gold = Kit.Mat("Gold", Gold, 1f, 0.7f);
        Vector3[] ps = { new Vector3(-4.5f, 2f, 1f), new Vector3(4.8f, -1.5f, 2f), new Vector3(-3.2f, -2.2f, 3f), new Vector3(3.6f, 2.4f, 4f) };
        for (int i = 0; i < ps.Length; i++)
        {
            var g = Kit.MeshObj("Floating Gem " + i, gemMesh, gemM, ps[i], Vector3.one * (1.3f + 0.2f * i), null);
            var f = g.AddComponent<FloatSpin>(); f.spin = new Vector3(0, 30 + 15 * i, 0); f.bobHeight = 0.2f; f.bobSpeed = 1f + 0.3f * i;
            var r = Kit.MeshObj("Floating Ring " + i, torus, gold, ps[i], Vector3.one * (12f + 2 * i), null);
            r.transform.localEulerAngles = new Vector3(70, 0, 20 * i);
            var rf = r.AddComponent<FloatSpin>(); rf.spin = new Vector3(0, 0, 25);
        }
        var nav = new GameObject("Scene Navigator").AddComponent<SceneNavigator>();
        var cv = Kit.MakeCanvas("Menu Canvas", false, V(1920, 1080));
        Kit.EventSys(false);
        Kit.Label(cv.transform, "Title", title, 80, Color.white, V(0.05f, 0.80f), V(0.95f, 0.96f), TextAnchor.MiddleCenter, FontStyle.Bold);
        Kit.Label(cv.transform, "Subtitle", subtitle, 36, new Color(0.6f, 0.85f, 1f), V(0.05f, 0.73f), V(0.95f, 0.81f));
        int n = labels.Length;
        float top = 0.68f, h = 0.12f, gap = 0.035f;
        for (int i = 0; i < n; i++)
        {
            float y1 = top - i * (h + gap);
            var b = Kit.Btn(cv.transform, "Menu Button " + (i + 1), labels[i], V(0.30f, y1 - h), V(0.70f, y1), i == n - 1 && targets[i] == "QUIT" ? Kit.Bad : (i % 2 == 0 ? Kit.Accent : new Color(0.35f, 0.3f, 0.85f)), 40);
            if (targets[i] == "QUIT") Kit.Click(b, nav, "Quit"); else Kit.ClickStr(b, nav, "Load", targets[i]);
        }
        var fp = Kit.Panel(cv.transform, "Features Panel", V(0.72f, 0.12f), V(0.98f, 0.66f), Kit.Panel1);
        Kit.Label(fp, "Features", features, 28, Color.white, V(0, 0), V(1, 1), TextAnchor.UpperLeft);
        Kit.Label(cv.transform, "Footer", "HICAS  |  MCA  |  25MCP20TP - AR & VR Practical  |  Unity 6.3 LTS", 26, new Color(1, 1, 1, 0.6f), V(0.05f, 0.02f), V(0.95f, 0.08f));
        return Kit.SaveScene(sc, sceneName);
    }

    // ------------------------------------------------------------------ presentation
    public static string ScenePresentation(string sceneName, string[] titles, string[] bodies, string menuScene)
    {
        var sc = Kit.NewScene();
        Kit.SimpleCamera(new Vector3(0, 1, -10), Vector3.zero, new Color(0.04f, 0.06f, 0.14f), false);
        var nav = new GameObject("Scene Navigator").AddComponent<SceneNavigator>();
        var cv = Kit.MakeCanvas("Slide Canvas", false, V(1920, 1080));
        Kit.EventSys(false);
        Kit.Panel(cv.transform, "Background", V(0, 0), V(1, 1), new Color(0.05f, 0.08f, 0.18f), null, null, false);
        Kit.Panel(cv.transform, "Accent Bar", V(0, 0.90f), V(1, 1), new Color(0.1f, 0.45f, 0.85f), null, null, false);
        var deck = new GameObject("Slide Deck").AddComponent<SlideDeck>();
        deck.titles = titles; deck.bodies = bodies;
        deck.titleText = Kit.Label(cv.transform, "Slide Title", "", 72, Color.white, V(0.04f, 0.90f), V(0.96f, 1f), TextAnchor.MiddleLeft, FontStyle.Bold);
        var bp = Kit.Panel(cv.transform, "Body Panel", V(0.05f, 0.20f), V(0.95f, 0.86f), new Color(1, 1, 1, 0.06f));
        deck.bodyText = Kit.Label(bp, "Slide Body", "", 44, Color.white, V(0, 0), V(1, 1), TextAnchor.UpperLeft, FontStyle.Normal, new Vector2(30, 20), new Vector2(-30, -20));
        deck.counterText = Kit.Label(cv.transform, "Counter", "", 34, new Color(1, 1, 1, 0.7f), V(0.44f, 0.04f), V(0.56f, 0.14f));
        var bPrev = Kit.Btn(cv.transform, "Prev", "< PREV", V(0.05f, 0.04f), V(0.22f, 0.14f), Kit.Accent, 36);
        var bNext = Kit.Btn(cv.transform, "Next", "NEXT >", V(0.78f, 0.04f), V(0.95f, 0.14f), Kit.Accent, 36);
        var bMenu = Kit.Btn(cv.transform, "Menu", "MENU", V(0.25f, 0.04f), V(0.38f, 0.14f), Kit.Bad, 36);
        Kit.Click(bPrev, deck, "Prev"); Kit.Click(bNext, deck, "Next"); Kit.ClickStr(bMenu, nav, "Load", menuScene);
        return Kit.SaveScene(sc, sceneName);
    }

    // ------------------------------------------------------------------ VR gallery / escape room
    public static string SceneGallery(string sceneName, string menuScene)
    {
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.42f, 0.42f, 0.46f));
        var floorM = Kit.Mat("GalleryFloor", new Color(0.30f, 0.20f, 0.14f), 0f, 0.5f);
        var wallM = Kit.Mat("GalleryWall", new Color(0.88f, 0.84f, 0.76f), 0f, 0.1f);
        var ceilM = Kit.Mat("GalleryCeiling", new Color(0.2f, 0.2f, 0.24f), 0f, 0.1f);
        var stone = Kit.Mat("Stone", new Color(0.75f, 0.7f, 0.6f), 0f, 0.2f);
        var goldM = Kit.Mat("Gold", Gold, 1f, 0.7f);
        var redM = Kit.Mat("RedPlinth", new Color(0.7f, 0.1f, 0.12f), 0f, 0.4f);
        var gemM = Kit.Mat("GemCrystal", new Color(0.35f, 0.8f, 1f), 0.2f, 0.9f, new Color(0.1f, 0.5f, 0.9f));
        var doorM = Kit.Mat("DoorMat", new Color(0.35f, 0.08f, 0.08f), 0.3f, 0.4f, new Color(0.25f, 0.02f, 0.02f));

        GameObject floor;
        Room(-7, 7, -6, 12, 4, floorM, wallM, ceilM, out floor);
        Kit.MakeLight("Directional Light", LightType.Directional, new Color(1, 0.97f, 0.9f), 0.5f, Vector3.zero, new Vector3(60, -20, 0));
        for (int i = 0; i < 4; i++) Kit.MakeLight("Gallery Light " + i, LightType.Point, new Color(1f, 0.9f, 0.75f), 1.1f, new Vector3((i % 2 == 0 ? -3f : 3f), 3.4f, -3f + (i / 2) * 6f), Vector3.zero, LightShadows.None, 9f);
        Kit.MakeLight("Exit Light", LightType.Point, new Color(0.5f, 1f, 0.6f), 1.2f, new Vector3(0, 3.2f, 9), Vector3.zero, LightShadows.None, 8f);

        // divider wall with door gap
        Kit.Prim(PrimitiveType.Cube, "Divider Left", new Vector3(-4.1f, 2f, 6f), new Vector3(5.8f, 4f, 0.25f), wallM);
        Kit.Prim(PrimitiveType.Cube, "Divider Right", new Vector3(4.1f, 2f, 6f), new Vector3(5.8f, 4f, 0.25f), wallM);
        Kit.Prim(PrimitiveType.Cube, "Divider Header", new Vector3(0, 3.5f, 6f), new Vector3(2.4f, 1f, 0.25f), wallM);

        // paintings
        float[] zs = { -3f, 1f, 4f };
        for (int i = 0; i < 6; i++)
        {
            bool left = i < 3; float x = left ? -6.86f : 6.86f; float z = zs[i % 3];
            Kit.Prim(PrimitiveType.Cube, "Frame " + (i + 1), new Vector3(x, 1.9f, z), new Vector3(0.06f, 1.7f, 1.7f), goldM);
            string file = "Painting_0" + (i + 1) + ".png";
            Kit.ConfigureTexture(file, 512, false, true);
            var pm = Kit.Mat("Painting" + (i + 1), Color.white, 0f, 0.3f, null, false, Kit.Tex(file));
            var q = Kit.Prim(PrimitiveType.Quad, "Painting " + (i + 1), new Vector3(left ? x + 0.04f : x - 0.04f, 1.9f, z), new Vector3(1.5f, 1.5f, 1), pm, null, false);
            Face(q.transform, new Vector3(0, 1.9f, z));
            Kit.MakeLight("Spot " + (i + 1), LightType.Point, new Color(1, 0.95f, 0.85f), 0.6f, new Vector3(left ? x + 1.2f : x - 1.2f, 3.2f, z), Vector3.zero, LightShadows.None, 3.5f);
        }

        var rig = KitXR.BuildVRRig(new Vector3(0, 0, -5), null);
        var tpArea = KitXR.TeleportArea(floor, rig.provider);
        var sfxClick = "Click.wav";

        // VR UI panel (world space)
        var panel = VRPanel("VR Gallery Panel", new Vector3(-3.6f, 1.6f, -4.2f), new Vector3(0, 1.6f, -5f), V(900, 700));
        var bg = Kit.Panel(panel.transform, "Background", V(0, 0), V(1, 1), Kit.Panel1);
        Kit.Label(bg, "Title", "GALLERY ESCAPE ROOM", 56, Color.white, V(0, 0.86f), V(1, 0.98f), TextAnchor.MiddleCenter, FontStyle.Bold);
        var status = Kit.Label(bg, "Status", "", 38, new Color(0.7f, 0.95f, 1f), V(0.03f, 0.58f), V(0.97f, 0.85f));
        var timer = Kit.Label(bg, "Timer", "Time 0 s", 36, Color.white, V(0.03f, 0.46f), V(0.97f, 0.58f));
        var hint = Kit.Label(bg, "Hint", "HINT: the golden key rests on the RED pedestal in the east corner. Carry it to the lock beside the door.", 32, new Color(1f, 0.85f, 0.4f), V(0.03f, 0.30f), V(0.97f, 0.46f));
        hint.gameObject.SetActive(false);
        var bHint = Kit.Btn(bg, "Hint Button", "HINT", V(0.04f, 0.05f), V(0.32f, 0.24f), Kit.Warn1, 38);
        var bReset = Kit.Btn(bg, "Reset Button", "RESET", V(0.36f, 0.05f), V(0.64f, 0.24f), Kit.Accent, 38);
        var bBack = Kit.Btn(bg, "Back Button", "BACK TO MENU", V(0.68f, 0.05f), V(0.96f, 0.24f), Kit.Bad, 32);
        Kit.EventSys(true);
        var nav = new GameObject("Scene Navigator").AddComponent<SceneNavigator>();
        Kit.ClickStr(bBack, nav, "Load", menuScene);

        // interactive artifacts on plinths
        var info = Kit.Label(bg, "Selected", "Grab an artifact with the grip / trigger", 30, Color.white, V(0.03f, 0.25f), V(0.97f, 0.31f));
        Vector3[] pp = { new Vector3(-3, 0, -1), new Vector3(0, 0, -3), new Vector3(3, 0, -1) };
        for (int i = 0; i < 3; i++)
        {
            Kit.Prim(PrimitiveType.Cube, "Plinth " + (i + 1), new Vector3(pp[i].x, 0.5f, pp[i].z), new Vector3(0.6f, 1f, 0.6f), stone);
            GameObject item;
            if (i == 0) item = Kit.MeshObj("Crystal Artifact", Kit.GemMesh("Gem"), gemM, new Vector3(pp[i].x, 1.2f, pp[i].z), Vector3.one * 0.25f, null, true);
            else if (i == 1) item = Kit.Prim(PrimitiveType.Sphere, "Golden Sphere", new Vector3(pp[i].x, 1.12f, pp[i].z), Vector3.one * 0.22f, goldM);
            else item = Kit.Prim(PrimitiveType.Cube, "Ancient Cube", new Vector3(pp[i].x, 1.1f, pp[i].z), Vector3.one * 0.2f, stone);
            KitXR.Grabbable(item, item.name, info, null);
        }

        // key + pedestal
        Kit.Prim(PrimitiveType.Cube, "Red Pedestal", new Vector3(5f, 0.5f, 3f), new Vector3(0.55f, 1f, 0.55f), redM);
        var key = new GameObject("Golden Key"); key.transform.position = new Vector3(5f, 1.08f, 3f);
        var kb = key.AddComponent<BoxCollider>(); kb.size = new Vector3(0.14f, 0.08f, 0.24f); kb.center = new Vector3(0, 0, 0.04f);
        Kit.Prim(PrimitiveType.Cylinder, "Key Ring", new Vector3(0, 0, -0.06f), new Vector3(0.1f, 0.01f, 0.1f), goldM, key.transform, false, new Vector3(90, 0, 0));
        Kit.Prim(PrimitiveType.Cube, "Key Shaft", new Vector3(0, 0, 0.08f), new Vector3(0.025f, 0.025f, 0.2f), goldM, key.transform, false);
        Kit.Prim(PrimitiveType.Cube, "Key Teeth", new Vector3(0, -0.02f, 0.15f), new Vector3(0.025f, 0.04f, 0.04f), goldM, key.transform, false);
        var keyGrab = KitXR.Grabbable(key, "Golden Key", info, KitXR.AddSfx(key, "Click.wav"));

        // door + lock
        var door = Kit.Prim(PrimitiveType.Cube, "Locked Door", new Vector3(0, 1.5f, 6f), new Vector3(2.4f, 3f, 0.2f), doorM);
        var dc = door.AddComponent<DoorController>(); dc.openOffset = new Vector3(0, 3.1f, 0);
        var success = KitXR.AddSfx(door, "Success.wav"); success.spatialBlend = 0.6f;
        dc.sfx = success;
        Kit.Prim(PrimitiveType.Cube, "Lock Box", new Vector3(2.0f, 1.2f, 5.8f), new Vector3(0.35f, 0.5f, 0.1f), Kit.Mat("LockMat", new Color(0.15f, 0.15f, 0.2f), 0.5f, 0.5f), null);
        var lockZone = Kit.Empty("Lock Zone", new Vector3(2.0f, 1.2f, 5.6f));
        Kit.Prim(PrimitiveType.Sphere, "Lock Glow", new Vector3(0, 0, 0), Vector3.one * 0.08f, Kit.Mat("LockGlow", Color.red, 0, 0.5f, new Color(0.9f, 0.1f, 0.1f)), lockZone.transform, false);
        var exit = Kit.Empty("Exit Marker", new Vector3(0, 0, 9f));
        Kit.Prim(PrimitiveType.Cylinder, "Exit Pad", new Vector3(0, 0.01f, 0), new Vector3(2f, 0.01f, 2f), Kit.Mat("ExitPad", Color.green, 0, 0.5f, new Color(0.1f, 0.7f, 0.2f)), exit.transform, false);

        var ge = new GameObject("Gallery Escape Logic").AddComponent<GalleryEscape>();
        ge.key = keyGrab; ge.lockZone = lockZone.transform; ge.exitMarker = exit.transform; ge.playerCamera = rig.cam.transform;
        ge.door = dc; ge.statusText = status; ge.hintText = hint; ge.timerText = timer; ge.sfx = success;
        Kit.Click(bHint, ge, "ToggleHint"); Kit.Click(bReset, ge, "ResetRoom");

        // desktop hint overlay
        var hud = Kit.MakeCanvas("Desktop Hint", false, V(1920, 1080));
        var ht = Kit.Label(hud.transform, "Hint", "", 30, Color.white, V(0.05f, 0.01f), V(0.95f, 0.08f));
        rig.origin.GetComponent<NoHeadsetPreview>().hint = ht;
        return Kit.SaveScene(sc, sceneName);
    }

    // ------------------------------------------------------------------ VR showcase (teleport + grab + UI + spatial sound)
    public static string SceneVRShowcase(string sceneName, string menuScene)
    {
        var sc = Kit.NewScene();
        Kit.Env(new Color(0.4f, 0.42f, 0.5f));
        var floorM = Kit.Mat("ShowFloor", new Color(0.18f, 0.2f, 0.26f), 0.1f, 0.6f);
        var wallM = Kit.Mat("ShowWall", new Color(0.55f, 0.6f, 0.72f), 0f, 0.2f);
        var ceilM = Kit.Mat("GalleryCeiling", new Color(0.2f, 0.2f, 0.24f), 0f, 0.1f);
        var goldM = Kit.Mat("Gold", Gold, 1f, 0.7f);
        var gemM = Kit.Mat("GemCrystal", new Color(0.35f, 0.8f, 1f), 0.2f, 0.9f, new Color(0.1f, 0.5f, 0.9f));
        var padM = Kit.Mat("PadGlow", new Color(0.2f, 0.9f, 1f), 0f, 0.5f, new Color(0.1f, 0.6f, 0.8f));
        var tableM = Kit.Mat("TableWood", new Color(0.4f, 0.28f, 0.18f), 0f, 0.4f);

        GameObject floor;
        Room(-8, 8, -8, 8, 4.5f, floorM, wallM, ceilM, out floor);
        Kit.MakeLight("Directional Light", LightType.Directional, Color.white, 0.6f, Vector3.zero, new Vector3(55, -30, 0));
        Kit.MakeLight("Point A", LightType.Point, new Color(1, 0.9f, 0.8f), 1.2f, new Vector3(-4, 3.5f, 2), Vector3.zero, LightShadows.None, 10);
        Kit.MakeLight("Point B", LightType.Point, new Color(0.8f, 0.9f, 1f), 1.2f, new Vector3(4, 3.5f, -2), Vector3.zero, LightShadows.None, 10);

        var rig = KitXR.BuildVRRig(new Vector3(0, 0, -6), null);
        KitXR.TeleportArea(floor, rig.provider);

        // teleport anchors
        Vector3[] ap = { new Vector3(-5.5f, 0, 3f), new Vector3(0, 0, 5.5f), new Vector3(5.5f, 0, 3f) };
        for (int i = 0; i < 3; i++)
        {
            var pad = Kit.Prim(PrimitiveType.Cylinder, "Teleport Pad " + (i + 1), new Vector3(ap[i].x, 0.03f, ap[i].z), new Vector3(1.4f, 0.03f, 1.4f), padM);
            var anchor = Kit.Empty("Anchor", new Vector3(0, 1f, 0), pad.transform);
            anchor.transform.position = new Vector3(ap[i].x, 0.06f, ap[i].z);
            KitXR.TeleportAnchor(pad, anchor.transform, rig.provider);
        }

        // VR UI
        var panel = VRPanel("VR Showcase Panel", new Vector3(0, 1.7f, -2.4f), new Vector3(0, 1.6f, -6f), V(900, 640));
        var bg = Kit.Panel(panel.transform, "Background", V(0, 0), V(1, 1), Kit.Panel1);
        Kit.Label(bg, "Title", "AR / VR FINAL SHOWCASE", 56, Color.white, V(0, 0.84f), V(1, 0.98f), TextAnchor.MiddleCenter, FontStyle.Bold);
        var info = Kit.Label(bg, "Info", "Teleport: aim at the floor/pads + trigger\nGrab: grip or trigger on an object\nUI: point + trigger", 34, new Color(0.7f, 0.95f, 1f), V(0.03f, 0.40f), V(0.97f, 0.84f));
        var sel = Kit.Label(bg, "Selected", "Selected: none", 38, new Color(1f, 0.85f, 0.4f), V(0.03f, 0.27f), V(0.97f, 0.40f));
        var bMusic = Kit.Btn(bg, "Music Button", "MUSIC ON/OFF", V(0.04f, 0.05f), V(0.32f, 0.24f), Kit.Accent, 34);
        var bReset = Kit.Btn(bg, "Reset Button", "RESET", V(0.36f, 0.05f), V(0.64f, 0.24f), Kit.Warn1, 38);
        var bBack = Kit.Btn(bg, "Back Button", "BACK TO MENU", V(0.68f, 0.05f), V(0.96f, 0.24f), Kit.Bad, 32);
        Kit.EventSys(true);
        var nav = new GameObject("Scene Navigator").AddComponent<SceneNavigator>();
        Kit.ClickStr(bBack, nav, "Load", menuScene);

        // spatial speaker
        var spk = Speaker(new Vector3(0, 0, 3.5f));
        var src = SpatialSource(spk, 2f, 22f, 0.8f);
        var viz = new GameObject("Sound Rings");
        var discT = Kit.Tex("Disc.png"); Kit.ConfigureTexture("Disc.png", 256, false, false); Kit.ConfigureTexture("Ring.png", 256, false, false);
        var minD = Kit.Prim(PrimitiveType.Quad, "Min Zone", new Vector3(0, 0.02f, 3.5f), Vector3.one, Kit.SprMat("ZoneMin", new Color(0.2f, 1f, 0.4f, 0.8f), discT), viz.transform, false, new Vector3(90, 0, 0));
        var maxD = Kit.Prim(PrimitiveType.Quad, "Max Zone", new Vector3(0, 0.015f, 3.5f), Vector3.one, Kit.SprMat("ZoneMax", new Color(1f, 0.6f, 0.1f, 0.35f), discT), viz.transform, false, new Vector3(90, 0, 0));
        var waves = new Transform[3];
        for (int i = 0; i < 3; i++) waves[i] = Kit.Prim(PrimitiveType.Quad, "Wave " + i, new Vector3(0, 0.03f, 3.5f), Vector3.one, Kit.SprMat("Wave" + i, new Color(0.4f, 0.9f, 1f, 0.8f), Kit.Tex("Ring.png")), viz.transform, false, new Vector3(90, 0, 0)).transform;
        var sv = viz.AddComponent<SoundSourceVisualizer>(); sv.source = src; sv.minDisc = minD.transform; sv.maxDisc = maxD.transform; sv.waves = waves;
        Kit.Label(Kit.MakeCanvas("Speaker Label", true, V(500, 120), 0.003f, spk.transform).transform, "Text", "SOUND SOURCE", 60, Color.white, V(0, 0), V(1, 1), TextAnchor.MiddleCenter, FontStyle.Bold);
        spk.transform.Find("Speaker Label").localPosition = new Vector3(0, 1.5f, 0);
        spk.transform.Find("Speaker Label").gameObject.AddComponent<FaceCamera>().yawOnly = true;
        Kit.Click(bMusic, spk.AddComponent<SpatialAudioToggle>(), "Toggle");

        // grabbable table items
        var table = Kit.Prim(PrimitiveType.Cube, "Table", new Vector3(-3.5f, 0.4f, -1f), new Vector3(1.8f, 0.8f, 1f), tableM);
        var clickSrc = KitXR.AddSfx(table, "Click.wav");
        GameObject[] items = {
            Kit.Prim(PrimitiveType.Cube, "Blue Cube", new Vector3(-4f, 0.9f, -1f), Vector3.one * 0.18f, Kit.Mat("CubeBlue", new Color(0.2f, 0.4f, 0.95f), 0, 0.5f)),
            Kit.Prim(PrimitiveType.Sphere, "Gold Sphere", new Vector3(-3.5f, 0.92f, -1f), Vector3.one * 0.2f, goldM),
            Kit.MeshObj("Crystal", Kit.GemMesh("Gem"), gemM, new Vector3(-3f, 0.95f, -1f), Vector3.one * 0.22f, null, true) };
        var grabs = new List<GrabbableObject>();
        foreach (var it in items) grabs.Add(KitXR.Grabbable(it, it.name, sel, clickSrc));
        var vw = new GameObject("Showcase Logic").AddComponent<VRWorkshop>();
        vw.selectedText = sel;
        Kit.Click(bReset, vw, "ResetScene");

        var hud = Kit.MakeCanvas("Desktop Hint", false, V(1920, 1080));
        var ht = Kit.Label(hud.transform, "Hint", "", 30, Color.white, V(0.05f, 0.01f), V(0.95f, 0.08f));
        rig.origin.GetComponent<NoHeadsetPreview>().hint = ht;
        return Kit.SaveScene(sc, sceneName);
    }
}
