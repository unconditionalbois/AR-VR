using UnityEngine;
using UnityEngine.UI;
public class InfoPanelController : MonoBehaviour
{
    public Text titleText, statusText, bodyText, buttonLabel;
    public GameObject details;
    public void SetStatus(string s) { if (statusText != null) statusText.text = s; }
    public void ToggleDetails()
    {
        if (details == null) return;
        details.SetActive(!details.activeSelf);
        if (buttonLabel != null) buttonLabel.text = details.activeSelf ? "HIDE INFO" : "MORE INFO";
    }
}
