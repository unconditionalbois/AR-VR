using UnityEngine;
using UnityEngine.UI;
public class VRWorkshop : MonoBehaviour
{
    public Text selectedText; public Light[] lights; public DoorController door;
    bool lightsOn = true;
    public void ResetScene()
    {
        foreach (var g in FindObjectsByType<GrabbableObject>(FindObjectsSortMode.None)) g.ResetPose();
        if (door != null) door.SetOpen(false);
        if (selectedText != null) selectedText.text = "Scene reset";
    }
    public void ToggleLights()
    {
        lightsOn = !lightsOn;
        foreach (var l in lights) if (l != null) l.enabled = lightsOn;
        RenderSettings.ambientLight = lightsOn ? new Color(0.45f, 0.47f, 0.52f) : new Color(0.08f, 0.08f, 0.1f);
        if (selectedText != null) selectedText.text = "Lights " + (lightsOn ? "ON" : "OFF");
    }
    public void ExitApp()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
