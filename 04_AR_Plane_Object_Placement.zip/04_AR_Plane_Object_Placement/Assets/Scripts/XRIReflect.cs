using UnityEngine;
public static class XRIReflect
{
    public static bool HasComponentNamed(GameObject go, string typeName)
    {
        foreach (var c in go.GetComponentsInParent<Component>())
            if (c != null && c.GetType().Name == typeName) return true;
        return false;
    }
}
