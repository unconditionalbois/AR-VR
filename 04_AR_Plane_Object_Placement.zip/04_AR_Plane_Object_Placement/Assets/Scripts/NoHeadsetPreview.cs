using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR;
using UnityEngine.InputSystem.XR;
public class NoHeadsetPreview : MonoBehaviour
{
    public Transform origin; public Camera cam; public Text hint;
    public float moveSpeed = 2.5f, lookSpeed = 0.25f;
    public bool headsetPresent;
    float yaw, pitch, nextCheck; bool firstCheck = true;
    Vector3 lastMouse, downPos; bool downOverUI;
    TrackedPoseDriver headDriver;
    void Start()
    {
        if (origin == null) origin = transform;
        if (cam == null) cam = GetComponentInChildren<Camera>();
        if (cam != null)
        {
            headDriver = cam.GetComponent<TrackedPoseDriver>();
            Vector3 e = cam.transform.localEulerAngles; yaw = e.y; pitch = e.x > 180f ? e.x - 360f : e.x;
        }
        Check();
    }
    void Check()
    {
        var d = InputDevices.GetDeviceAtXRNode(XRNode.Head);
        bool present = d.isValid;
        if (present != headsetPresent || firstCheck)
        {
            headsetPresent = present; firstCheck = false;
            if (headDriver != null) headDriver.enabled = present;
            if (hint != null)
                hint.text = present ? "VR headset detected: trigger = select / teleport / UI, grip = grab."
                                    : "No headset: desktop preview. WASD = move, hold Right Mouse = look, click floor = teleport, click UI. (Touch: drag = look, tap floor = teleport)";
        }
    }
    bool OverUI()
    {
        if (EventSystem.current == null) return false;
        if (Input.touchCount > 0) return EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId);
        return EventSystem.current.IsPointerOverGameObject();
    }
    void Update()
    {
        if (Time.unscaledTime > nextCheck) { nextCheck = Time.unscaledTime + 1f; Check(); }
        if (headsetPresent || cam == null) return;
        bool changed = false;
        if (Input.GetMouseButtonDown(1)) lastMouse = Input.mousePosition;
        if (Input.GetMouseButton(1))
        {
            Vector3 d = Input.mousePosition - lastMouse; lastMouse = Input.mousePosition;
            yaw += d.x * lookSpeed; pitch -= d.y * lookSpeed; changed = true;
        }
        else if (Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Moved && !OverUI())
        {
            Vector2 d = Input.GetTouch(0).deltaPosition; yaw += d.x * 0.12f; pitch -= d.y * 0.12f; changed = true;
        }
        if (changed) { pitch = Mathf.Clamp(pitch, -80f, 80f); cam.transform.localRotation = Quaternion.Euler(pitch, yaw, 0f); }

        Vector3 move = Vector3.zero;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) move += Vector3.forward;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) move += Vector3.back;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) move += Vector3.left;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) move += Vector3.right;
        if (move != Vector3.zero) origin.position += Quaternion.Euler(0, yaw, 0) * move.normalized * moveSpeed * Time.deltaTime;

        if (Input.GetMouseButtonDown(0)) { downPos = Input.mousePosition; downOverUI = OverUI(); }
        if (Input.GetMouseButtonUp(0) && !downOverUI && (Input.mousePosition - downPos).magnitude < 12f)
        {
            Ray r = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(r, out hit, 80f, ~0, QueryTriggerInteraction.Ignore))
                if (XRIReflect.HasComponentNamed(hit.collider.gameObject, "TeleportationArea") || XRIReflect.HasComponentNamed(hit.collider.gameObject, "TeleportationAnchor"))
                    origin.position = hit.point;
        }
    }
}
