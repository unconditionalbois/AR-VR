using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Text;
public class ComponentsDemo : MonoBehaviour
{
    public Text hierarchyText, inspectorText;
    public GameObject prefab;
    public Transform spawnRoot;
    GameObject selected; int count;
    void Start() { RefreshHierarchy(); Select(null); }
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !(EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit)) Select(hit.collider.gameObject);
        }
    }
    public void Select(GameObject g)
    {
        selected = g;
        if (inspectorText == null) return;
        if (g == null) { inspectorText.text = "<b>INSPECTOR</b>\nClick any object in the scene to inspect its Components."; return; }
        var sb = new StringBuilder();
        sb.AppendLine("<b>INSPECTOR</b>");
        sb.AppendLine("Name: " + g.name + "   Tag: " + g.tag);
        foreach (var c in g.GetComponents<Component>())
        {
            if (c == null) continue;
            sb.AppendLine("- " + c.GetType().Name);
            if (c is Transform t)
                sb.AppendLine("    Pos " + t.position.ToString("0.0") + "  Rot " + t.eulerAngles.ToString("0") + "  Scale " + t.localScale.ToString("0.0"));
        }
        inspectorText.text = sb.ToString();
    }
    void RefreshHierarchy()
    {
        if (hierarchyText == null) return;
        var sb = new StringBuilder("<b>HIERARCHY</b>\n");
        foreach (var go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
            if (go.GetComponentInChildren<Canvas>() == null && go.GetComponent<EventSystem>() == null) sb.AppendLine("- " + go.name);
        hierarchyText.text = sb.ToString();
    }
    public void SpawnPrefab()
    {
        if (prefab == null) return;
        var go = Instantiate(prefab, new Vector3(Random.Range(-4f, 4f), Random.Range(2f, 4f), Random.Range(-1f, 3f)), Random.rotation, spawnRoot);
        go.name = prefab.name + " (Instance " + (++count) + ")";
        RefreshHierarchy();
    }
    public void AddRigidbody()
    {
        if (selected != null && selected.GetComponent<Rigidbody>() == null) { selected.AddComponent<Rigidbody>(); Select(selected); }
    }
    public void ToggleCollider()
    {
        if (selected == null) return;
        var c = selected.GetComponent<Collider>();
        if (c != null) { c.enabled = !c.enabled; }
        Select(selected);
    }
    public void ToggleRenderer()
    {
        if (selected == null) return;
        var r = selected.GetComponent<Renderer>();
        if (r != null) r.enabled = !r.enabled;
    }
}
