using UnityEngine;
public class PressButton : MonoBehaviour
{
    public DoorController door; public Transform cap; public Renderer lamp;
    float t;
    public void Press()
    {
        if (door != null) door.Toggle();
        t = 0.25f;
        if (lamp != null) lamp.material.color = (door != null && door.IsOpen) ? Color.green : Color.red;
    }
    void Update()
    {
        if (cap == null) return;
        t = Mathf.Max(0, t - Time.deltaTime);
        cap.localPosition = new Vector3(cap.localPosition.x, t > 0 ? -0.02f : 0f, cap.localPosition.z);
    }
}
