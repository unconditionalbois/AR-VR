using UnityEngine;
using UnityEngine.UI;
public class MobileOptimizer : MonoBehaviour
{
    public Text label;
    bool optimized;
    void Start() { Apply(true); }
    public void Toggle() { Apply(!optimized); }
    public void Apply(bool on)
    {
        optimized = on;
        if (on)
        {
            Application.targetFrameRate = 60; QualitySettings.vSyncCount = 0;
            QualitySettings.shadows = ShadowQuality.Disable; QualitySettings.pixelLightCount = 1;
            QualitySettings.antiAliasing = 0; QualitySettings.anisotropicFiltering = AnisotropicFiltering.Disable;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }
        else
        {
            Application.targetFrameRate = -1; QualitySettings.shadows = ShadowQuality.All; QualitySettings.pixelLightCount = 4;
            QualitySettings.antiAliasing = 4; QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;
        }
        if (label != null)
            label.text = "<b>MOBILE OPTIMIZATION: " + (on ? "ON" : "OFF") + "</b>\n- Target 60 FPS, VSync off\n- Realtime shadows " + (on ? "disabled" : "enabled") + "\n- Pixel lights " + (on ? "1" : "4") + ", MSAA " + (on ? "off" : "4x") + "\n- Static batching, ADPCM mono audio, 1024px textures\n- Low-poly primitives, no post-processing";
    }
}
