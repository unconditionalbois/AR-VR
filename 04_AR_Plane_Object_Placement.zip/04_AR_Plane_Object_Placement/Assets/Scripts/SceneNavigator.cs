using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneNavigator : MonoBehaviour
{
    public void Load(string sceneName) { SceneManager.LoadScene(sceneName); }
    public void ReloadCurrent() { SceneManager.LoadScene(SceneManager.GetActiveScene().name); }
    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
