using UnityEngine;
public class DesktopPoseFix : MonoBehaviour
{
    void Awake()
    {
        if (Application.isMobilePlatform) return;
        var d = GetComponent<UnityEngine.InputSystem.XR.TrackedPoseDriver>();
        if (d != null) d.enabled = false;
    }
}
