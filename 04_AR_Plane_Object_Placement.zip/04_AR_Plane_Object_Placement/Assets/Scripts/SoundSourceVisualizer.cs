using UnityEngine;
public class SoundSourceVisualizer : MonoBehaviour
{
    public AudioSource source; public Transform minDisc, maxDisc; public Transform[] waves;
    Renderer[] waveR;
    void Start()
    {
        waveR = new Renderer[waves.Length];
        for (int i = 0; i < waves.Length; i++) waveR[i] = waves[i].GetComponent<Renderer>();
    }
    void Update()
    {
        if (source == null) return;
        float mn = source.minDistance, mx = source.maxDistance;
        if (minDisc != null) minDisc.localScale = new Vector3(mn * 2f, mn * 2f, 1f);
        if (maxDisc != null) maxDisc.localScale = new Vector3(mx * 2f, mx * 2f, 1f);
        for (int i = 0; i < waves.Length; i++)
        {
            float ph = (Time.time * 0.3f + (float)i / waves.Length) % 1f;
            float r = Mathf.Lerp(mn * 0.5f, mx, ph);
            waves[i].localScale = new Vector3(r * 2f, r * 2f, 1f);
            var c = waveR[i].material.color; c.a = (1f - ph) * (source.isPlaying && !source.mute ? 0.9f : 0f); waveR[i].material.color = c;
        }
    }
}
