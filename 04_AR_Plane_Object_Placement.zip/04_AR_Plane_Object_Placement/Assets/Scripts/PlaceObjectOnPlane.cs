using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

// Based on the practical record program (tap a detected plane -> Instantiate object),
// extended with a reticle, UI hooks and an editor/desktop preview mode.
public class PlaceObjectOnPlane : MonoBehaviour
{
    public GameObject objectToPlace;
    public ARPlaneManager planeManager;
    public GameObject indicator;
    public Text statusText;
    public int maxObjects = 25;

    private ARRaycastManager raycastManager;
    private static List<ARRaycastHit> hits = new List<ARRaycastHit>();
    private readonly List<GameObject> placed = new List<GameObject>();
    private bool showPlanes = true;
    private float nextVis;

    static bool Preview { get { return !Application.isMobilePlatform; } }

    void Awake() { raycastManager = GetComponent<ARRaycastManager>(); }

    void Update()
    {
        ApplyPlaneVisibility();
        UpdateIndicator();
        HandleInput();
        UpdateStatus();
    }

    bool OverUI(int id)
    {
        if (EventSystem.current == null) return false;
        return id < 0 ? EventSystem.current.IsPointerOverGameObject() : EventSystem.current.IsPointerOverGameObject(id);
    }

    bool PreviewRaycast(Vector2 screen, out Pose pose)
    {
        pose = default(Pose);
        if (Camera.main == null) return false;
        Ray r = Camera.main.ScreenPointToRay(screen);
        RaycastHit hit;
        if (Physics.Raycast(r, out hit, 60f) && hit.collider.name == "Editor Preview Floor")
        {
            pose = new Pose(hit.point, Quaternion.identity);
            return true;
        }
        return false;
    }

    void HandleInput()
    {
        if (Preview)
        {
            Pose p;
            if (Input.GetMouseButtonDown(0) && !OverUI(-1) && PreviewRaycast(Input.mousePosition, out p)) Place(p);
            return;
        }
        if (Input.touchCount == 0) return;
        Touch touch = Input.GetTouch(0);
        if (touch.phase != TouchPhase.Began) return;
        if (OverUI(touch.fingerId)) return;
        if (raycastManager.Raycast(touch.position, hits, TrackableType.PlaneWithinPolygon))
        {
            Pose hitPose = hits[0].pose;
            Place(hitPose);
        }
    }

    void Place(Pose pose)
    {
        if (objectToPlace == null) return;
        if (placed.Count >= maxObjects) { Destroy(placed[0]); placed.RemoveAt(0); }
        float yaw = Camera.main != null ? Camera.main.transform.eulerAngles.y + 180f : 0f;
        placed.Add(Instantiate(objectToPlace, pose.position, Quaternion.Euler(0f, yaw, 0f)));
    }

    void UpdateIndicator()
    {
        if (indicator == null) return;
        Pose p = default(Pose); bool ok;
        if (Preview) ok = PreviewRaycast(Input.mousePosition, out p);
        else
        {
            ok = raycastManager.Raycast(new Vector2(Screen.width * 0.5f, Screen.height * 0.5f), hits, TrackableType.PlaneWithinPolygon);
            if (ok) p = hits[0].pose;
        }
        indicator.SetActive(ok);
        if (ok) indicator.transform.SetPositionAndRotation(p.position, p.rotation);
    }

    void ApplyPlaneVisibility()
    {
        if (planeManager == null || Time.unscaledTime < nextVis) return;
        nextVis = Time.unscaledTime + 0.25f;
        foreach (var plane in planeManager.trackables)
            foreach (var r in plane.GetComponentsInChildren<Renderer>()) r.enabled = showPlanes;
    }

    void UpdateStatus()
    {
        if (statusText == null) return;
        int planes = planeManager != null ? planeManager.trackables.count : 0;
        string s;
        if (Preview) s = "EDITOR PREVIEW - click the grid floor to place the object";
        else if (ARSession.state == ARSessionState.Unsupported) s = "AR is not supported on this device";
        else if (planes == 0) s = "Move your phone slowly to scan the floor or a table...";
        else s = "Plane detected - tap it to place the object";
        statusText.text = s + "\nPlanes: " + planes + "    Objects placed: " + placed.Count;
    }

    public void ClearAll() { foreach (var g in placed) if (g != null) Destroy(g); placed.Clear(); }
    public void UndoLast() { if (placed.Count > 0) { Destroy(placed[placed.Count - 1]); placed.RemoveAt(placed.Count - 1); } }
    public void TogglePlanes() { showPlanes = !showPlanes; nextVis = 0f; }
}
