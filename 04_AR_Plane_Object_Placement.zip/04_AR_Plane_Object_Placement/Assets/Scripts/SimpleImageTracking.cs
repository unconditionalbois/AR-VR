using UnityEngine;
using UnityEngine.XR.ARFoundation;

// Practical record program, updated to the AR Foundation 6 API (trackablesChanged).
public class SimpleImageTracking : MonoBehaviour
{
    public ARTrackedImageManager imageManager;

    private void OnEnable() { imageManager.trackablesChanged.AddListener(OnImageChanged); }
    private void OnDisable() { imageManager.trackablesChanged.RemoveListener(OnImageChanged); }

    private void OnImageChanged(ARTrackablesChangedEventArgs<ARTrackedImage> args)
    {
        foreach (ARTrackedImage image in args.added)
            Debug.Log("Image Detected: " + image.referenceImage.name);
        foreach (ARTrackedImage image in args.updated)
            if (image.trackingState != UnityEngine.XR.ARSubsystems.TrackingState.Tracking)
                Debug.Log("Image Updated (not fully tracked): " + image.referenceImage.name);
    }
}
