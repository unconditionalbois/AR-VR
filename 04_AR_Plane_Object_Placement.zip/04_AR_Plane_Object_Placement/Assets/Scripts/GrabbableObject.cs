using UnityEngine;
using UnityEngine.UI;
[RequireComponent(typeof(Rigidbody))]
public class GrabbableObject : MonoBehaviour
{
    public string displayName = "Object";
    public Text infoText; public AudioSource sfx; public Renderer tint;
    public Color grabColor = new Color(1f, 0.85f, 0.2f);
    public bool Held { get; private set; }
    Vector3 startPos; Quaternion startRot; Color baseColor = Color.white; Rigidbody rb; MaterialPropertyBlock mpb;
    void Awake()
    {
        rb = GetComponent<Rigidbody>(); startPos = transform.position; startRot = transform.rotation;
        if (tint == null) tint = GetComponentInChildren<Renderer>();
        if (tint != null && tint.sharedMaterial != null && tint.sharedMaterial.HasProperty("_Color")) baseColor = tint.sharedMaterial.color;
    }
    public void OnGrabbed() { Held = true; if (infoText != null) infoText.text = "Selected: " + displayName.ToUpper(); SetColor(grabColor); if (sfx != null) sfx.Play(); }
    public void OnReleased() { Held = false; if (infoText != null) infoText.text = "Released: " + displayName; SetColor(baseColor); }
    void SetColor(Color c)
    {
        if (tint == null) return;
        if (mpb == null) mpb = new MaterialPropertyBlock();
        tint.GetPropertyBlock(mpb); mpb.SetColor("_Color", c); tint.SetPropertyBlock(mpb);
    }
    public void ResetPose()
    {
        Held = false;
        if (rb != null && !rb.isKinematic) { rb.linearVelocity = Vector3.zero; rb.angularVelocity = Vector3.zero; }
        transform.SetPositionAndRotation(startPos, startRot);
        SetColor(baseColor);
    }
}
