using UnityEngine;
public class TrackedImageContent : MonoBehaviour
{
    GameObject content;
    public string shownName;
    public void Show(string imageName, GameObject prefab, bool visible, Vector2 size)
    {
        if (content == null && prefab != null)
        {
            content = Instantiate(prefab, transform);
            content.transform.localPosition = Vector3.zero;
            content.transform.localRotation = Quaternion.identity;
            float s = size.x > 0.001f ? size.x / 0.2f : 1f;
            content.transform.localScale = Vector3.one * s;
            shownName = imageName;
        }
        if (content != null)
        {
            content.SetActive(visible);
            var panel = content.GetComponentInChildren<InfoPanelController>(true);
            if (panel != null) panel.SetStatus(visible ? "STATUS: TRACKING" : "STATUS: LIMITED");
        }
    }
    public void Hide() { if (content != null) content.SetActive(false); }
}
