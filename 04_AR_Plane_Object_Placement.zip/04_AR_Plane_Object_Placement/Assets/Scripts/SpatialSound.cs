using UnityEngine;
public class SpatialSound : MonoBehaviour
{
    void Start()
    {
        GetComponent<AudioSource>().spatialBlend = 1f;
    }
}
