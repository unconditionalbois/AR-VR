using UnityEngine;
[RequireComponent(typeof(Canvas))]
public class WorldCanvasSetup : MonoBehaviour
{
    Canvas canvas; float next;
    void Awake() { canvas = GetComponent<Canvas>(); }
    void Update()
    {
        if (canvas.worldCamera == null && Time.unscaledTime >= next)
        {
            next = Time.unscaledTime + 0.5f;
            Camera cam = Camera.main;
            if (cam == null) cam = FindFirstObjectByType<Camera>();
            canvas.worldCamera = cam;
        }
    }
}
