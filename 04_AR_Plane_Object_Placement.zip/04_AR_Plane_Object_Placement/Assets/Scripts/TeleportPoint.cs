using UnityEngine;
public class TeleportPoint : MonoBehaviour
{
    public Transform player;
    public void TeleportPlayer()
    {
        player.position = transform.position;
    }
}
