using UnityEngine;
using UnityEngine.UI;
public class SlideDeck : MonoBehaviour
{
    public Text titleText, bodyText, counterText;
    public string[] titles, bodies;
    int index;
    void Start() { Show(0); }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.Space)) Next();
        if (Input.GetKeyDown(KeyCode.LeftArrow)) Prev();
    }
    public void Next() { Show(Mathf.Min(index + 1, titles.Length - 1)); }
    public void Prev() { Show(Mathf.Max(index - 1, 0)); }
    void Show(int i)
    {
        index = i;
        if (titleText) titleText.text = titles[i];
        if (bodyText) bodyText.text = bodies[i];
        if (counterText) counterText.text = (i + 1) + " / " + titles.Length;
    }
}
