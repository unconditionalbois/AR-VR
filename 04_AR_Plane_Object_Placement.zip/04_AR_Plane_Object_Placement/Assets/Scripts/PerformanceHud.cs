using UnityEngine;
using UnityEngine.UI;
public class PerformanceHud : MonoBehaviour
{
    public Text label;
    float timer; int frames;
    void Update()
    {
        timer += Time.unscaledDeltaTime; frames++;
        if (timer >= 0.5f)
        {
            float fps = frames / timer; frames = 0; timer = 0;
            if (label != null) label.text = fps.ToString("0") + " FPS   " + (1000f / Mathf.Max(fps, 1f)).ToString("0.0") + " ms   Mem " + (System.GC.GetTotalMemory(false) / 1048576f).ToString("0.0") + " MB";
        }
    }
}
