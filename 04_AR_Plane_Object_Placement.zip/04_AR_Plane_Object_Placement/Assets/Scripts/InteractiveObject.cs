using UnityEngine;
public class InteractiveObject : MonoBehaviour
{
    public Color[] colors = { Color.red, Color.yellow, Color.green, Color.cyan };
    int i; Renderer r; Rigidbody rb;
    void Awake() { r = GetComponent<Renderer>(); rb = GetComponent<Rigidbody>(); }
    void OnMouseDown() { Activate(); }
    public void Activate()
    {
        i = (i + 1) % colors.Length;
        if (r != null) r.material.color = colors[i];
        if (rb != null && !rb.isKinematic) rb.AddForce(Vector3.up * 4f, ForceMode.Impulse);
    }
}
