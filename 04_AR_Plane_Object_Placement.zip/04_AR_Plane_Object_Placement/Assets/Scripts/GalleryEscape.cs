using UnityEngine;
using UnityEngine.UI;
public class GalleryEscape : MonoBehaviour
{
    public GrabbableObject key; public Transform lockZone, exitMarker, playerCamera;
    public DoorController door; public Text statusText, hintText, timerText; public AudioSource sfx;
    bool unlocked, escaped; float t0, finish;
    void Start() { t0 = Time.time; Refresh(); }
    void Update()
    {
        if (!escaped && timerText != null) timerText.text = "Time " + (Time.time - t0).ToString("0") + " s";
        if (!unlocked && key != null && !key.Held && Vector3.Distance(key.transform.position, lockZone.position) < 0.25f) Unlock();
        if (unlocked && !escaped && playerCamera != null)
        {
            Vector3 a = playerCamera.position, b = exitMarker.position; a.y = b.y = 0;
            if (Vector3.Distance(a, b) < 1.3f) { escaped = true; finish = Time.time - t0; if (statusText) statusText.text = "YOU ESCAPED in " + finish.ToString("0") + " s!"; if (sfx) sfx.Play(); }
        }
    }
    void Unlock()
    {
        unlocked = true;
        var rb = key.GetComponent<Rigidbody>(); if (rb) rb.isKinematic = true;
        key.transform.SetPositionAndRotation(lockZone.position, lockZone.rotation);
        door.SetOpen(true);
        if (sfx) sfx.Play();
        Refresh();
    }
    void Refresh()
    {
        if (statusText) statusText.text = unlocked ? "DOOR UNLOCKED - walk through the exit!" : "Find the golden key and insert it into the lock by the door.";
    }
    public void ToggleHint()
    {
        if (hintText) hintText.gameObject.SetActive(!hintText.gameObject.activeSelf);
    }
    public void ResetRoom()
    {
        unlocked = false; escaped = false; t0 = Time.time;
        var rb = key.GetComponent<Rigidbody>(); if (rb) rb.isKinematic = false;
        key.ResetPose(); door.SetOpen(false); Refresh();
    }
}
