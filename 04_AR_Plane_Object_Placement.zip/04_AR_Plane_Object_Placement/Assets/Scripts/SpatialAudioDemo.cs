using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class SpatialAudioDemo : MonoBehaviour
{
    public AudioSource source; public Transform listener, rig;
    public Slider volume, minDist, maxDist, blend, walk;
    public Text readout, rolloffLabel, muteLabel;
    void Start()
    {
        if (source != null)
        {
            source.spatialBlend = 1f;
            if (volume) volume.SetValueWithoutNotify(source.volume);
            if (minDist) minDist.SetValueWithoutNotify(source.minDistance);
            if (maxDist) maxDist.SetValueWithoutNotify(source.maxDistance);
            if (blend) blend.SetValueWithoutNotify(source.spatialBlend);
        }
    }
    public void SetVolume(float v) { if (source) source.volume = v; }
    public void SetMin(float v) { if (source) { source.minDistance = Mathf.Min(v, source.maxDistance - 0.5f); } }
    public void SetMax(float v) { if (source) { source.maxDistance = Mathf.Max(v, source.minDistance + 0.5f); } }
    public void SetBlend(float v) { if (source) source.spatialBlend = v; }
    public void Walk(float distance) { if (rig != null) rig.position = new Vector3(rig.position.x, rig.position.y, source.transform.position.z - distance); }
    public void ToggleRolloff()
    {
        if (!source) return;
        source.rolloffMode = source.rolloffMode == AudioRolloffMode.Logarithmic ? AudioRolloffMode.Linear : AudioRolloffMode.Logarithmic;
    }
    public void ToggleMute() { if (source) source.mute = !source.mute; }
    void Update()
    {
        if (source == null || listener == null) return;
        Vector3 d3 = source.transform.position - listener.position;
        float d = d3.magnitude, mn = source.minDistance, mx = source.maxDistance;
        float dc = Mathf.Clamp(d, mn, mx);
        float gain = source.rolloffMode == AudioRolloffMode.Linear ? 1f - (dc - mn) / Mathf.Max(0.01f, mx - mn) : mn / dc;
        gain *= source.volume * (source.mute ? 0f : 1f);
        float pan = Vector3.Dot(listener.right, d3.normalized);
        string side = pan < -0.25f ? "LEFT ear" : (pan > 0.25f ? "RIGHT ear" : "CENTER");
        if (readout) readout.text = "Distance: " + d.ToString("0.0") + " m\nSpatial Blend: " + source.spatialBlend.ToString("0.00") + " (1 = full 3D)\nMin " + mn.ToString("0.0") + " m  /  Max " + mx.ToString("0.0") + " m\nRolloff: " + source.rolloffMode + "\nEstimated loudness: " + (gain * 100f).ToString("0") + "%\nSound comes from: " + side;
        if (rolloffLabel) rolloffLabel.text = "Rolloff: " + source.rolloffMode;
        if (muteLabel) muteLabel.text = source.mute ? "Unmute" : "Mute";
        if (walk && !(EventSystem.current != null && EventSystem.current.currentSelectedGameObject == walk.gameObject)) walk.SetValueWithoutNotify(Mathf.Clamp(Mathf.Abs(listener.position.z - source.transform.position.z), walk.minValue, walk.maxValue));
    }
}
