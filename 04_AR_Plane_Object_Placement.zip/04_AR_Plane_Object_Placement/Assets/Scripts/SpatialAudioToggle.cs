using UnityEngine;
public class SpatialAudioToggle : MonoBehaviour
{
    public void Toggle()
    {
        var a = GetComponent<AudioSource>();
        if (a != null) a.mute = !a.mute;
    }
}
