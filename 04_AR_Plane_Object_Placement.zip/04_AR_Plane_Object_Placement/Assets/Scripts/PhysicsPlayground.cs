using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class PhysicsPlayground : MonoBehaviour
{
    public Text infoText; public Slider massSlider, forceSlider;
    public Material cubeMat, sphereMat; public Transform spawnRoot;
    public PhysicsMaterial bouncy;
    float mass = 1f; bool gravityOn = true;
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !(EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit) && hit.rigidbody != null)
                hit.rigidbody.AddForceAtPosition(ray.direction * (forceSlider != null ? forceSlider.value : 5f), hit.point, ForceMode.Impulse);
        }
        if (infoText != null)
            infoText.text = "Rigidbodies: " + FindObjectsByType<Rigidbody>(FindObjectsSortMode.None).Length + "\nGravity: " + (gravityOn ? "ON" : "OFF") + "\nMass for new objects: " + mass.ToString("0.0") + " kg\nTip: click an object to push it";
    }
    public void SetMass(float v) { mass = v; }
    Vector3 SpawnPos() { return new Vector3(Random.Range(-3f, 3f), Random.Range(6f, 9f), Random.Range(-2f, 3f)); }
    public void SpawnCube() { Make(PrimitiveType.Cube, cubeMat, null); }
    public void SpawnSphere() { Make(PrimitiveType.Sphere, sphereMat, bouncy); }
    void Make(PrimitiveType t, Material m, PhysicsMaterial pm)
    {
        var g = GameObject.CreatePrimitive(t);
        g.transform.SetParent(spawnRoot, false);
        g.transform.position = SpawnPos(); g.transform.rotation = Random.rotation;
        g.transform.localScale = Vector3.one * Random.Range(0.6f, 1.1f);
        g.name = "Spawned " + t;
        if (m != null) g.GetComponent<Renderer>().sharedMaterial = m;
        var rb = g.AddComponent<Rigidbody>(); rb.mass = mass; rb.useGravity = gravityOn;
        if (pm != null) g.GetComponent<Collider>().sharedMaterial = pm;
    }
    public void Explode()
    {
        float f = forceSlider != null ? forceSlider.value * 60f : 300f;
        foreach (var rb in FindObjectsByType<Rigidbody>(FindObjectsSortMode.None)) rb.AddExplosionForce(f, new Vector3(0, -0.5f, 0), 14f, 2f, ForceMode.Impulse);
    }
    public void ToggleGravity()
    {
        gravityOn = !gravityOn;
        foreach (var rb in FindObjectsByType<Rigidbody>(FindObjectsSortMode.None)) { rb.useGravity = gravityOn; rb.WakeUp(); }
    }
    public void ResetScene() { SceneManager.LoadScene(SceneManager.GetActiveScene().name); }
}
