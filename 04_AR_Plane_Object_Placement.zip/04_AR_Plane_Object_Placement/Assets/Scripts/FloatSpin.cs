using UnityEngine;
public class FloatSpin : MonoBehaviour
{
    public Vector3 spin = new Vector3(0f, 45f, 0f);
    public float bobHeight = 0f;
    public float bobSpeed = 1.5f;
    Vector3 basePos;
    void Start() { basePos = transform.localPosition; }
    void Update()
    {
        transform.Rotate(spin * Time.deltaTime, Space.Self);
        if (bobHeight > 0f) transform.localPosition = basePos + Vector3.up * (Mathf.Sin(Time.time * bobSpeed) * bobHeight);
    }
}
