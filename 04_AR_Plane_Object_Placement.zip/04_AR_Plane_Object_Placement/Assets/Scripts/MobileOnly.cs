using UnityEngine;
public class MobileOnly : MonoBehaviour
{
    void Awake() { if (!Application.isMobilePlatform) gameObject.SetActive(false); }
}
