using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class TrackedImageController : MonoBehaviour
{
    [Serializable] public class Entry { public string imageName; public GameObject contentPrefab; }
    public ARTrackedImageManager manager;
    public Entry[] entries;
    public Text statusText, detectedText;
    public Transform previewPoster;
    GameObject simulated;

    void OnEnable() { if (manager != null) manager.trackablesChanged.AddListener(OnChanged); }
    void OnDisable() { if (manager != null) manager.trackablesChanged.RemoveListener(OnChanged); }
    void Start() { SetStatus("Scanning... point the camera at the target poster"); }

    GameObject Find(string n)
    {
        foreach (var e in entries) if (e.imageName == n) return e.contentPrefab;
        return entries.Length > 0 ? entries[0].contentPrefab : null;
    }

    void OnChanged(ARTrackablesChangedEventArgs<ARTrackedImage> args)
    {
        foreach (var img in args.added) Handle(img);
        foreach (var img in args.updated) Handle(img);
    }

    void Handle(ARTrackedImage img)
    {
        string n = img.referenceImage.name;
        var holder = img.GetComponent<TrackedImageContent>();
        if (holder == null) holder = img.gameObject.AddComponent<TrackedImageContent>();
        bool tracking = img.trackingState == TrackingState.Tracking;
        holder.Show(n, Find(n), tracking, img.size);
        if (tracking) { SetStatus("Image detected!"); if (detectedText != null) detectedText.text = "Detected: " + n; }
        else SetStatus("Tracking limited - keep the poster in view");
    }

    void SetStatus(string s) { if (statusText != null) statusText.text = s; }

    public void ToggleInfo()
    {
        foreach (var p in FindObjectsByType<InfoPanelController>(FindObjectsSortMode.None)) p.ToggleDetails();
    }

    // Editor / desktop preview (no camera feed available on PC)
    public void SimulateDetection()
    {
        if (simulated != null || previewPoster == null || entries.Length == 0) return;
        simulated = new GameObject("Simulated Tracked Image");
        simulated.transform.SetPositionAndRotation(previewPoster.position, Quaternion.identity);
        var h = simulated.AddComponent<TrackedImageContent>();
        h.Show(entries[0].imageName, entries[0].contentPrefab, true, new Vector2(0.2f, 0.2f));
        SetStatus("Image detected! (simulated in editor)");
        if (detectedText != null) detectedText.text = "Detected: " + entries[0].imageName;
    }

    public void ResetScan()
    {
        if (simulated != null) Destroy(simulated);
        simulated = null;
        foreach (var h in FindObjectsByType<TrackedImageContent>(FindObjectsSortMode.None)) h.Hide();
        SetStatus("Scanning... point the camera at the target poster");
        if (detectedText != null) detectedText.text = "Detected: none";
    }
}
