using UnityEngine;
public class Orbiter : MonoBehaviour
{
    public float radius = 0.1f, speed = 90f, height = 0f, phase = 0f;
    float angle;
    void Start() { angle = phase; }
    void Update()
    {
        angle += speed * Time.deltaTime;
        float r = angle * Mathf.Deg2Rad;
        transform.localPosition = new Vector3(Mathf.Cos(r) * radius, height, Mathf.Sin(r) * radius);
    }
}
