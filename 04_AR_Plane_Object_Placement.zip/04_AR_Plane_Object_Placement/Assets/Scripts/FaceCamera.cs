using UnityEngine;
public class FaceCamera : MonoBehaviour
{
    public bool yawOnly = false;
    void LateUpdate()
    {
        Camera cam = Camera.main;
        if (cam == null) return;
        Vector3 d = transform.position - cam.transform.position;
        if (yawOnly) d.y = 0f;
        if (d.sqrMagnitude < 0.0001f) return;
        transform.rotation = Quaternion.LookRotation(d);
    }
}
