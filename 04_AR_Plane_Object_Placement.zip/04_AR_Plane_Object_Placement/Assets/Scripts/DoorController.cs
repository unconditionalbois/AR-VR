using UnityEngine;
public class DoorController : MonoBehaviour
{
    public Vector3 openOffset = new Vector3(0, 2.6f, 0);
    public float speed = 2f; public AudioSource sfx;
    public bool IsOpen { get; private set; }
    Vector3 closed;
    void Awake() { closed = transform.localPosition; }
    public void SetOpen(bool open) { if (open != IsOpen && sfx != null) sfx.Play(); IsOpen = open; }
    public void Open() { SetOpen(true); }
    public void Close() { SetOpen(false); }
    public void Toggle() { SetOpen(!IsOpen); }
    void Update() { transform.localPosition = Vector3.MoveTowards(transform.localPosition, IsOpen ? closed + openOffset : closed, speed * Time.deltaTime); }
}
