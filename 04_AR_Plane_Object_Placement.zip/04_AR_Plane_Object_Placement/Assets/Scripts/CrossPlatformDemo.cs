using UnityEngine;
using UnityEngine.UI;
public class CrossPlatformDemo : MonoBehaviour
{
    public Text infoText; float next;
    void Update()
    {
        if (Time.unscaledTime < next || infoText == null) return;
        next = Time.unscaledTime + 1f;
        var head = UnityEngine.XR.InputDevices.GetDeviceAtXRNode(UnityEngine.XR.XRNode.Head);
        string input = head.isValid ? "XR headset + controllers" : (Application.isMobilePlatform ? "Touch screen (tap objects, drag to look)" : "Mouse + keyboard (click objects, WASD, right-mouse look)");
        infoText.text = "<b>CROSS-PLATFORM XR SCENE</b>\nPlatform: " + Application.platform + "\nDevice: " + SystemInfo.deviceModel + "\nXR headset: " + (head.isValid ? "detected" : "none") + "\nActive input: " + input;
    }
}
