using UnityEngine;
public class DesktopOnly : MonoBehaviour
{
    void Awake() { if (Application.isMobilePlatform) gameObject.SetActive(false); }
}
