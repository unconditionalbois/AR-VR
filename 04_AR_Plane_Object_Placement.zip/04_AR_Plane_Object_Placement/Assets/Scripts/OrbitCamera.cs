using UnityEngine;
using UnityEngine.EventSystems;
public class OrbitCamera : MonoBehaviour
{
    public Transform target; public float distance = 12f, yaw = 25f, pitch = 28f;
    Vector3 last;
    void LateUpdate()
    {
        bool overUI = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();
        if (Input.GetMouseButtonDown(1)) last = Input.mousePosition;
        if (Input.GetMouseButton(1))
        {
            Vector3 d = Input.mousePosition - last; last = Input.mousePosition;
            yaw += d.x * 0.25f; pitch -= d.y * 0.25f;
        }
        else if (Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Moved && !overUI)
        {
            Vector2 d = Input.GetTouch(0).deltaPosition; yaw += d.x * 0.2f; pitch -= d.y * 0.2f;
        }
        distance = Mathf.Clamp(distance - Input.mouseScrollDelta.y * 0.8f, 4f, 30f);
        pitch = Mathf.Clamp(pitch, 5f, 85f);
        Vector3 c = target != null ? target.position : Vector3.zero;
        transform.position = c + Quaternion.Euler(pitch, yaw, 0) * new Vector3(0, 0, -distance);
        transform.LookAt(c);
    }
}
