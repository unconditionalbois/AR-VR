using UnityEngine;
using UnityEngine.InputSystem;
public class EnableInputActions : MonoBehaviour
{
    public InputActionAsset asset;
    void OnEnable() { if (asset != null) asset.Enable(); }
    void OnDisable() { if (asset != null) asset.Disable(); }
}
